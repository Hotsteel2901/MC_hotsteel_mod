package com.hotsteel.mixin;

import com.hotsteel.logic.SuperFireResistanceHandler;
import com.hotsteel.registry.ModItems;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    /**
     * While Super Fire Resistance is active, treat lava as water inside {@code travel()} so the
     * player moves through lava with water physics (buoyancy + horizontal momentum) instead of the
     * sluggish vanilla lava physics. A Dolphin's-Grace effect applied by
     * {@link SuperFireResistanceHandler} then makes the movement noticeably faster than water.
     * <p>
     * The redirect is scoped to {@code travel()} only, so vanilla {@code updateSwimming()} and
     * {@code updatePlayerPose()} still see the real {@code isInWater()} (false for lava) — the
     * player keeps a normal standing pose in lava, no swim-pose twitch.
     */
    @Redirect(
        method = "travel",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;isInWater()Z"))
    private boolean hotsteel$lavaAsWater(class_1309 self) {
        if (self instanceof class_1657
            && SuperFireResistanceHandler.isActive(self)
            && SuperFireResistanceHandler.isBodyTouchingLava(self)) {
            return true;
        }
        return self.method_5799();
    }

    /** A Hot Steel shield sets the attacker on fire when it blocks a melee hit. */
    @Inject(method = "blockUsingShield", at = @At("TAIL"))
    private void hotsteel$igniteBlockedAttacker(class_1309 attacker, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (!self.method_37908().method_8608()
            && self.method_6030().method_31574(ModItems.HOT_STEEL_SHIELD)) {
            attacker.method_5639(5.0f);
        }
    }
}
