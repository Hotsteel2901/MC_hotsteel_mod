package com.hotsteel.client;

import com.hotsteel.registry.ModEntities;
import com.hotsteel.registry.ModItems;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1764;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_9278;
import net.minecraft.class_9334;

public class HotSteelClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.HOT_STEEL_TRIDENT, HotSteelTridentRenderer::new);
        EntityRendererRegistry.register(ModEntities.HOT_STEEL_ARROW, HotSteelArrowRenderer::new);

        class_2960 pull = class_2960.method_60656("pull");
        class_2960 pulling = class_2960.method_60656("pulling");
        class_2960 charged = class_2960.method_60656("charged");
        class_2960 firework = class_2960.method_60656("firework");

        // Bow
        class_5272.method_27879(ModItems.HOT_STEEL_BOW, pull, (stack, level, entity, seed) -> {
            if (entity == null || entity.method_6030() != stack) {
                return 0.0f;
            }
            return (stack.method_7935(entity) - entity.method_6014()) / 20.0f;
        });
        class_5272.method_27879(ModItems.HOT_STEEL_BOW, pulling, (stack, level, entity, seed) ->
            entity != null && entity.method_6115() && entity.method_6030() == stack ? 1.0f : 0.0f);

        // Crossbow
        class_5272.method_27879(ModItems.HOT_STEEL_CROSSBOW, pull, (stack, level, entity, seed) -> {
            if (entity == null) {
                return 0.0f;
            }
            if (class_1764.method_7781(stack)) {
                return 0.0f;
            }
            return (float) (stack.method_7935(entity) - entity.method_6014())
                / class_1764.method_7775(stack, entity);
        });
        class_5272.method_27879(ModItems.HOT_STEEL_CROSSBOW, pulling, (stack, level, entity, seed) ->
            entity != null && entity.method_6115() && entity.method_6030() == stack
                && !class_1764.method_7781(stack) ? 1.0f : 0.0f);
        class_5272.method_27879(ModItems.HOT_STEEL_CROSSBOW, charged, (stack, level, entity, seed) ->
            class_1764.method_7781(stack) ? 1.0f : 0.0f);
        class_5272.method_27879(ModItems.HOT_STEEL_CROSSBOW, firework, (stack, level, entity, seed) -> {
            class_9278 cp = stack.method_57824(class_9334.field_49649);
            return cp != null && cp.method_57438(class_1802.field_8639) ? 1.0f : 0.0f;
        });

        // Shield: raise-to-front pose when blocking
        class_5272.method_27879(ModItems.HOT_STEEL_SHIELD,
            class_2960.method_60656("blocking"),
            (stack, level, entity, seed) ->
                entity != null && entity.method_6115() && entity.method_6030() == stack ? 1.0f : 0.0f);
    }
}
