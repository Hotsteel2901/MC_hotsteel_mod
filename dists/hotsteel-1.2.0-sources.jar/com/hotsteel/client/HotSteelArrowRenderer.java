package com.hotsteel.client;

import com.hotsteel.HotSteel;
import com.hotsteel.entity.HotSteelArrowEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_876;

/** Renders the Hot Steel arrow with its own molten-hot texture. */
public class HotSteelArrowRenderer extends class_876<HotSteelArrowEntity> {

    public static final class_2960 TEXTURE = HotSteel.id("textures/entity/hot_steel_arrow.png");

    public HotSteelArrowRenderer(class_5617.class_5618 context) {
        super(context);
    }

    @Override
    public class_2960 getTextureLocation(HotSteelArrowEntity entity) {
        return TEXTURE;
    }
}
