package com.hotsteel.datagen;

import java.util.concurrent.CompletableFuture;

import com.hotsteel.registry.ModBlocks;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7923;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {

    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries) {
        super(output, registries);
    }

    private static class_5321<class_2248> key(class_2248 block) {
        return class_7923.field_41175.method_29113(block).orElseThrow();
    }

    @Override
    protected void method_10514(class_7225.class_7874 registries) {
        this.method_10512(class_3481.field_33715)
            .method_46835(key(ModBlocks.CRUDE_STEEL_BLOCK))
            .method_46835(key(ModBlocks.STEEL_BLOCK))
            .method_46835(key(ModBlocks.HOT_STEEL_BLOCK));
        this.method_10512(class_3481.field_33719)
            .method_46835(key(ModBlocks.CRUDE_STEEL_BLOCK))
            .method_46835(key(ModBlocks.STEEL_BLOCK));
        this.method_10512(class_3481.field_33717).method_46835(key(ModBlocks.HOT_STEEL_BLOCK));
        // Hot steel block can power beacons like the vanilla metal blocks.
        this.method_10512(class_3481.field_22275).method_46835(key(ModBlocks.HOT_STEEL_BLOCK));
    }
}
