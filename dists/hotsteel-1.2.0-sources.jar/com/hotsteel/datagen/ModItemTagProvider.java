package com.hotsteel.datagen;

import java.util.concurrent.CompletableFuture;

import com.hotsteel.registry.ModItems;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_1792;
import net.minecraft.class_3489;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7923;

public class ModItemTagProvider extends FabricTagProvider.ItemTagProvider {

    public ModItemTagProvider(FabricDataOutput output,
                              CompletableFuture<class_7225.class_7874> registries,
                              FabricTagProvider.BlockTagProvider blockTags) {
        super(output, registries, blockTags);
    }

    private static class_5321<class_1792> k(class_1792 item) {
        return class_7923.field_41178.method_29113(item).orElseThrow();
    }

    @Override
    protected void method_10514(class_7225.class_7874 registries) {
        // Tool type tags
        this.method_10512(class_3489.field_42611).method_46835(k(ModItems.HOT_STEEL_SWORD)).method_46835(k(ModItems.HOT_STEEL_KNIFE));
        this.method_10512(class_3489.field_50109).method_46835(k(ModItems.HOT_STEEL_MACE));
        this.method_10512(class_3489.field_42614).method_46835(k(ModItems.HOT_STEEL_PICKAXE));
        this.method_10512(class_3489.field_42612).method_46835(k(ModItems.HOT_STEEL_AXE));
        this.method_10512(class_3489.field_42615).method_46835(k(ModItems.HOT_STEEL_SHOVEL));
        this.method_10512(class_3489.field_42613).method_46835(k(ModItems.HOT_STEEL_HOE));

        // Melee enchantability
        this.method_10512(class_3489.field_48304).method_46835(k(ModItems.HOT_STEEL_SWORD)).method_46835(k(ModItems.HOT_STEEL_KNIFE));
        this.method_10512(class_3489.field_50107).method_46835(k(ModItems.HOT_STEEL_SWORD)).method_46835(k(ModItems.HOT_STEEL_KNIFE));
        this.method_10512(class_3489.field_50108)
            .method_46835(k(ModItems.HOT_STEEL_SWORD)).method_46835(k(ModItems.HOT_STEEL_KNIFE)).method_46835(k(ModItems.HOT_STEEL_AXE));
        this.method_10512(class_3489.field_48305)
            .method_46835(k(ModItems.HOT_STEEL_SWORD)).method_46835(k(ModItems.HOT_STEEL_KNIFE)).method_46835(k(ModItems.HOT_STEEL_AXE));

        // Mining enchantability
        this.method_10512(class_3489.field_48306)
            .method_46835(k(ModItems.HOT_STEEL_PICKAXE)).method_46835(k(ModItems.HOT_STEEL_AXE))
            .method_46835(k(ModItems.HOT_STEEL_SHOVEL)).method_46835(k(ModItems.HOT_STEEL_HOE));
        this.method_10512(class_3489.field_48307)
            .method_46835(k(ModItems.HOT_STEEL_PICKAXE)).method_46835(k(ModItems.HOT_STEEL_AXE))
            .method_46835(k(ModItems.HOT_STEEL_SHOVEL)).method_46835(k(ModItems.HOT_STEEL_HOE));

        // Ranged / trident
        this.method_10512(class_3489.field_48311).method_46835(k(ModItems.HOT_STEEL_BOW));
        this.method_10512(class_3489.field_48313).method_46835(k(ModItems.HOT_STEEL_CROSSBOW));
        this.method_10512(class_3489.field_48309).method_46835(k(ModItems.HOT_STEEL_TRIDENT));
        // Arrows usable by bows / dispensers
        this.method_10512(class_3489.field_18317).method_46835(k(ModItems.HOT_STEEL_ARROW));

        // Armor
        this.method_10512(class_3489.field_48303)
            .method_46835(k(ModItems.HOT_STEEL_HELMET)).method_46835(k(ModItems.HOT_STEEL_CHESTPLATE))
            .method_46835(k(ModItems.HOT_STEEL_LEGGINGS)).method_46835(k(ModItems.HOT_STEEL_BOOTS));
        this.method_10512(class_3489.field_48312)
            .method_46835(k(ModItems.HOT_STEEL_HELMET)).method_46835(k(ModItems.HOT_STEEL_CHESTPLATE))
            .method_46835(k(ModItems.HOT_STEEL_LEGGINGS)).method_46835(k(ModItems.HOT_STEEL_BOOTS));
        this.method_10512(class_3489.field_48302).method_46835(k(ModItems.HOT_STEEL_HELMET));
        this.method_10512(class_3489.field_48301).method_46835(k(ModItems.HOT_STEEL_CHESTPLATE));
        this.method_10512(class_3489.field_48300).method_46835(k(ModItems.HOT_STEEL_LEGGINGS));
        this.method_10512(class_3489.field_48299).method_46835(k(ModItems.HOT_STEEL_BOOTS));

        // Durability + vanishing for everything
        this.method_10512(class_3489.field_48310)
            .method_46835(k(ModItems.HOT_STEEL_HELMET)).method_46835(k(ModItems.HOT_STEEL_CHESTPLATE))
            .method_46835(k(ModItems.HOT_STEEL_LEGGINGS)).method_46835(k(ModItems.HOT_STEEL_BOOTS))
            .method_46835(k(ModItems.HOT_STEEL_SWORD)).method_46835(k(ModItems.HOT_STEEL_MACE)).method_46835(k(ModItems.HOT_STEEL_KNIFE))
            .method_46835(k(ModItems.HOT_STEEL_PICKAXE))
            .method_46835(k(ModItems.HOT_STEEL_AXE)).method_46835(k(ModItems.HOT_STEEL_SHOVEL)).method_46835(k(ModItems.HOT_STEEL_HOE))
            .method_46835(k(ModItems.HOT_STEEL_BOW)).method_46835(k(ModItems.HOT_STEEL_CROSSBOW))
            .method_46835(k(ModItems.HOT_STEEL_TRIDENT)).method_46835(k(ModItems.HOT_STEEL_SHIELD));
        this.method_10512(class_3489.field_48314)
            .method_46835(k(ModItems.HOT_STEEL_HELMET)).method_46835(k(ModItems.HOT_STEEL_CHESTPLATE))
            .method_46835(k(ModItems.HOT_STEEL_LEGGINGS)).method_46835(k(ModItems.HOT_STEEL_BOOTS))
            .method_46835(k(ModItems.HOT_STEEL_SWORD)).method_46835(k(ModItems.HOT_STEEL_MACE)).method_46835(k(ModItems.HOT_STEEL_KNIFE))
            .method_46835(k(ModItems.HOT_STEEL_PICKAXE))
            .method_46835(k(ModItems.HOT_STEEL_AXE)).method_46835(k(ModItems.HOT_STEEL_SHOVEL)).method_46835(k(ModItems.HOT_STEEL_HOE))
            .method_46835(k(ModItems.HOT_STEEL_BOW)).method_46835(k(ModItems.HOT_STEEL_CROSSBOW))
            .method_46835(k(ModItems.HOT_STEEL_TRIDENT)).method_46835(k(ModItems.HOT_STEEL_SHIELD));
    }
}
