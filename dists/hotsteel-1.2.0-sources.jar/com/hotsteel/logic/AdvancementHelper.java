package com.hotsteel.logic;

import com.hotsteel.HotSteel;
import net.minecraft.class_3222;
import net.minecraft.class_8779;
import net.minecraft.server.MinecraftServer;

/** Small helper for awarding mod advancements from server-side logic. */
public final class AdvancementHelper {

    private AdvancementHelper() {}

    /**
     * Awards the advancement at {@code data/hotsteel/advancement/<path>.json} using
     * the given criterion (the JSON must define an "impossible" trigger with that name).
     */
    public static void award(class_3222 player, String path, String criterion) {
        MinecraftServer server = player.method_51469().method_8503();
        class_8779 holder = server.method_3851().method_12896(HotSteel.id(path));
        if (holder != null) {
            player.method_14236().method_12878(holder, criterion);
        }
    }
}
