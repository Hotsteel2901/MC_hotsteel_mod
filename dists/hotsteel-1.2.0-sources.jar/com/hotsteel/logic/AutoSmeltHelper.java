package com.hotsteel.logic;

import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

/**
 * Auto-smelt mapping for the Hot Steel pickaxe. Kept OUT of the Block mixin so
 * that no {@code Items}/{@code Blocks} reference sits inside {@code Block}'s
 * static initializer (a mixin {@code @Unique} static field there caused a
 * circular class-initialization crash in vanilla {@code FireBlock}). This class
 * is only touched lazily at runtime, when a block is actually mined.
 */
public final class AutoSmeltHelper {

    private AutoSmeltHelper() {}

    /** Maps a mined drop item to its smelted (ingot) form. */
    public static final Map<class_1792, class_1792> SMELT_MAP = Map.ofEntries(
        Map.entry(class_1802.field_33400, class_1802.field_8620),
        Map.entry(class_1802.field_33402, class_1802.field_8695),
        Map.entry(class_1802.field_33401, class_1802.field_27022),
        Map.entry(class_1802.field_8599, class_1802.field_8620),
        Map.entry(class_1802.field_29020, class_1802.field_8620),
        Map.entry(class_1802.field_8775, class_1802.field_8695),
        Map.entry(class_1802.field_29019, class_1802.field_8695),
        Map.entry(class_1802.field_27018, class_1802.field_27022),
        Map.entry(class_1802.field_29211, class_1802.field_27022),
        Map.entry(class_1802.field_23140, class_1802.field_8695),
        Map.entry(class_1802.field_8702, class_1802.field_8155),
        Map.entry(class_1802.field_22019, class_1802.field_22021),
        Map.entry(class_1802.field_33505, class_1802.field_8773),
        Map.entry(class_1802.field_33507, class_1802.field_8494),
        Map.entry(class_1802.field_33506, class_1802.field_27071)
    );
}
