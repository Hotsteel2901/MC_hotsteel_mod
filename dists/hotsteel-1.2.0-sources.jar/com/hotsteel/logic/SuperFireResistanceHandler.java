package com.hotsteel.logic;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.hotsteel.registry.ModEffects;
import com.hotsteel.registry.ModItems;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_8103;

/**
 * Drives the Hot Steel armor set bonuses:
 * <ul>
 *   <li><b>2+ pieces — Flame Ward:</b> immune to fire damage (fire, magma, fireballs…),
 *       but lava still hurts without the full set.</li>
 *   <li><b>4 pieces + fire environment — Super Fire Resistance:</b> up to 60s of full
 *       fire/lava immunity plus water-like lava movement (Dolphin's Grace speed boost),
 *       with a HUD countdown effect.</li>
 * </ul>
 * Also announces set bonus activation and awards the matching advancements.
 */
public final class SuperFireResistanceHandler {

    private SuperFireResistanceHandler() {}

    private static final int MAX_TICKS = 1200; // 60 seconds
    private static final Map<UUID, Integer> TIMER = new HashMap<>();
    private static final Set<UUID> HAD_FULL_SET = new HashSet<>();
    private static final Set<UUID> HAD_TWO_SET = new HashSet<>();

    /** Client-safe check: driven by the auto-synced marker effect. */
    public static boolean isActive(class_1309 entity) {
        return entity.method_6059(ModEffects.SUPER_FIRE_RESISTANCE);
    }

    /**
     * Returns true if any part of the entity's bounding box intersects a lava block.
     * <p>
     * Vanilla {@link class_1309#method_5771()} only checks the fluid at the entity's eye level,
     * which causes rapid on/off toggling when the player bobs at the lava surface. Checking the
     * whole bounding box keeps the effect and speed boost stable across that bobbing.
     */
    public static boolean isBodyTouchingLava(class_1309 entity) {
        if (entity.method_5771()) {
            return true; // fast path: eye-level check is enough when fully submerged
        }
        class_238 box = entity.method_5829();
        class_1937 level = entity.method_37908();
        int minX = class_3532.method_15357(box.field_1323);
        int minY = class_3532.method_15357(box.field_1322);
        int minZ = class_3532.method_15357(box.field_1321);
        int maxX = class_3532.method_15357(box.field_1320);
        int maxY = class_3532.method_15357(box.field_1325);
        int maxZ = class_3532.method_15357(box.field_1324);
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (level.method_8316(pos.method_10103(x, y, z)).method_15767(class_3486.field_15518)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static void register() {
        // Run BEFORE entity ticks so the marker effect is already present when the
        // swimming/pose mixin runs inside Player.tick().
        ServerTickEvents.START_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                tick(player);
            }
        });

        // Cancel fire/lava damage:
        //  - 2+ pieces: immune to all fire-tag damage EXCEPT direct lava (lava still burns
        //    without the full set, keeping the 4-piece super meaningful).
        //  - 4 pieces + timer active: full immunity including lava.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof class_3222 player && source.method_48789(class_8103.field_42246)) {
                int pieces = countPieces(player);
                boolean fullSuper = pieces >= 4 && TIMER.getOrDefault(player.method_5667(), 0) < MAX_TICKS;
                boolean flameWard = pieces >= 2 && !"lava".equals(source.method_48792().comp_1242());
                if (fullSuper || flameWard) {
                    return false;
                }
            }
            return true;
        });
    }

    private static void tick(class_3222 player) {
        UUID id = player.method_5667();
        int pieces = countPieces(player);

        // Announce the 2-piece Flame Ward becoming active / inactive.
        boolean hadTwo = HAD_TWO_SET.contains(id);
        if (pieces >= 2 && !hadTwo) {
            HAD_TWO_SET.add(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.flame_ward_on").method_27692(class_124.field_1065),
                false);
            AdvancementHelper.award(player, "set_bonus_2", "wear_two_pieces");
        } else if (pieces < 2 && hadTwo) {
            HAD_TWO_SET.remove(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.flame_ward_off").method_27692(class_124.field_1061),
                false);
        }

        // Announce the 4-piece Super Fire Resistance set becoming complete / incomplete.
        boolean fullSet = pieces >= 4;
        boolean hadFull = HAD_FULL_SET.contains(id);
        if (fullSet && !hadFull) {
            HAD_FULL_SET.add(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.super_fire_on").method_27692(class_124.field_1065),
                false);
            AdvancementHelper.award(player, "full_armor", "wear_full_set");
        } else if (!fullSet && hadFull) {
            HAD_FULL_SET.remove(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.super_fire_off").method_27692(class_124.field_1061),
                false);
        }

        // Super Fire Resistance timer + lava speed boost (full set + fire environment).
        boolean inLava = isBodyTouchingLava(player);
        boolean inFire = inLava || player.method_5809();
        if (fullSet && inFire) {
            int elapsed = TIMER.getOrDefault(id, 0) + 1;
            TIMER.put(id, elapsed);
            if (elapsed <= MAX_TICKS) {
                player.method_5646();
                int remaining = MAX_TICKS - elapsed + 1;
                player.method_6092(new class_1293(ModEffects.SUPER_FIRE_RESISTANCE,
                    remaining, 0, true, false, true));
                // Invisible speed boost so the player moves through lava faster than water.
                if (inLava) {
                    player.method_6092(new class_1293(class_1294.field_5900,
                        remaining, 1, false, false, false));
                }
            } else {
                player.method_6016(ModEffects.SUPER_FIRE_RESISTANCE);
                player.method_6016(class_1294.field_5900);
            }
        } else {
            TIMER.remove(id);
            if (player.method_6059(ModEffects.SUPER_FIRE_RESISTANCE)) {
                player.method_6016(ModEffects.SUPER_FIRE_RESISTANCE);
            }
            if (player.method_6059(class_1294.field_5900)) {
                player.method_6016(class_1294.field_5900);
            }
        }
    }

    /** Number of Hot Steel armor pieces currently worn (0–4). */
    private static int countPieces(class_1657 player) {
        int count = 0;
        if (player.method_6118(class_1304.field_6169).method_31574(ModItems.HOT_STEEL_HELMET)) count++;
        if (player.method_6118(class_1304.field_6174).method_31574(ModItems.HOT_STEEL_CHESTPLATE)) count++;
        if (player.method_6118(class_1304.field_6172).method_31574(ModItems.HOT_STEEL_LEGGINGS)) count++;
        if (player.method_6118(class_1304.field_6166).method_31574(ModItems.HOT_STEEL_BOOTS)) count++;
        return count;
    }
}
