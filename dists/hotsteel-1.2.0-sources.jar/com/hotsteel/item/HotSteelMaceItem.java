package com.hotsteel.item;

import net.minecraft.class_1322;
import net.minecraft.class_5134;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9362;

/**
 * Hot Steel mace: a heavy smash weapon (keeps vanilla MaceItem's high-fall
 * smash mechanics) with higher base damage and hot-steel durability. Melee hits
 * also ignite targets (handled by the shared hot-steel melee mixin).
 */
public class HotSteelMaceItem extends class_9362 {

    public HotSteelMaceItem(class_1793 properties) {
        super(properties);
    }

    public static class_9285 method_59532() {
        return class_9285.method_57480()
            .method_57487(class_5134.field_23721,
                new class_1322(field_8006, 8.0, class_1322.class_1323.field_6328),
                class_9274.field_49217)
            .method_57487(class_5134.field_23723,
                new class_1322(field_8001, -3.0, class_1322.class_1323.field_6328),
                class_9274.field_49217)
            .method_57486();
    }
}
