package com.hotsteel.item;

import com.hotsteel.entity.HotSteelArrowEntity;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1744;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

/** Hot Steel arrow: flies like a normal arrow but ignites whatever it hits. */
public class HotSteelArrowItem extends class_1744 {

    public HotSteelArrowItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1665 method_7702(class_1937 level, class_1799 stack, class_1309 shooter,
                                     class_1799 leftoverItemStack) {
        return new HotSteelArrowEntity(level, shooter, stack.method_7972());
    }
}
