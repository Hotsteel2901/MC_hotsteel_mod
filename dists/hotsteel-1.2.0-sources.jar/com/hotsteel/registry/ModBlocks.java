package com.hotsteel.registry;

import com.hotsteel.HotSteel;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public final class ModBlocks {

    private ModBlocks() {}

    public static final class_2248 CRUDE_STEEL_BLOCK = registerBlock("crude_steel_block",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10085)
            .method_31710(class_3620.field_15978)
            .method_9629(5.0f, 6.0f)
            .method_9626(class_2498.field_11533)
            .method_29292()));

    /** Storage block for steel ingots. */
    public static final class_2248 STEEL_BLOCK = registerBlock("steel_block",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10085)
            .method_31710(class_3620.field_16005)
            .method_9629(6.0f, 8.0f)
            .method_9626(class_2498.field_11533)
            .method_29292()));

    /** Storage block for hot steel ingots — near-netherite toughness, beacon-compatible,
     *  glows like an active forge. */
    public static final class_2248 HOT_STEEL_BLOCK = registerBlock("hot_steel_block",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_22108)
            .method_31710(class_3620.field_16002)
            .method_9629(50.0f, 1200.0f)
            .method_9626(class_2498.field_22150)
            .method_9631(state -> 15)
            .method_29292()));

    private static class_2248 registerBlock(String name, class_2248 block) {
        class_2960 id = HotSteel.id(name);
        class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new class_1792.class_1793()));
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    public static void register() {
        HotSteel.LOGGER.info("Registering Hot Steel blocks");
    }
}
