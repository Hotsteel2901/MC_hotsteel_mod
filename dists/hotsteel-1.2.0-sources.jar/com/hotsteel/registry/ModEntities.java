package com.hotsteel.registry;

import com.hotsteel.HotSteel;
import com.hotsteel.entity.HotSteelArrowEntity;
import com.hotsteel.entity.HotSteelTridentEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public final class ModEntities {

    private ModEntities() {}

    public static final class_1299<HotSteelTridentEntity> HOT_STEEL_TRIDENT = register(
        "hot_steel_trident",
        class_1299.class_1300.<HotSteelTridentEntity>method_5903(HotSteelTridentEntity::new, class_1311.field_17715)
            .method_17687(0.5f, 0.5f)
            .method_27299(4)
            .method_27300(20)
            .method_5905("hot_steel_trident"));

    public static final class_1299<HotSteelArrowEntity> HOT_STEEL_ARROW = register(
        "hot_steel_arrow",
        class_1299.class_1300.<HotSteelArrowEntity>method_5903(HotSteelArrowEntity::new, class_1311.field_17715)
            .method_17687(0.5f, 0.5f)
            .method_27299(4)
            .method_27300(20)
            .method_5905("hot_steel_arrow"));

    private static <T extends class_1297> class_1299<T> register(String name, class_1299<T> type) {
        return class_2378.method_10230(class_7923.field_41177, HotSteel.id(name), type);
    }

    public static void register() {
        HotSteel.LOGGER.info("Registering Hot Steel entities");
    }
}
