package com.hotsteel.mixin;

import java.util.Set;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_8103;
import com.hotsteel.logic.SuperFireResistanceHandler;
import com.hotsteel.registry.ModItems;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    /** All Hot Steel melee weapons ignite targets on hit. */
    @Unique
    private static final Set<class_1792> HOT_MELEE = Set.of(
        ModItems.HOT_STEEL_SWORD, ModItems.HOT_STEEL_KNIFE, ModItems.HOT_STEEL_AXE,
        ModItems.HOT_STEEL_MACE, ModItems.HOT_STEEL_TRIDENT);

    /** Fire ticks applied to a target hit by a Hot Steel melee weapon (4s). */
    @Unique
    private static final int IGNITE_TICKS = 80;

    /**
     * While Super Fire Resistance is active, treat lava as water inside {@code travel()} so the
     * player moves through lava with water physics (buoyancy + horizontal momentum) instead of the
     * sluggish vanilla lava physics. A Dolphin's-Grace effect applied by
     * {@link SuperFireResistanceHandler} then makes the movement noticeably faster than water.
     * <p>
     * The redirect is scoped to {@code travel()} only, so vanilla {@code updateSwimming()} and
     * {@code updatePlayerPose()} still see the real {@code isInWater()} (false for lava) — the
     * player keeps a normal standing pose in lava, no swim-pose twitch.
     */
    @Redirect(
        method = "travel",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;isInWater()Z"))
    private boolean hotsteel$lavaAsWater(class_1309 self) {
        if (self instanceof class_1657
            && SuperFireResistanceHandler.isActive(self)
            && SuperFireResistanceHandler.isBodyTouchingLava(self)) {
            return true;
        }
        return self.method_5799();
    }

    /**
     * Hot Steel melee weapons set the target on fire. Fires only on actual melee damage
     * (direct attacker is a Player holding a Hot Steel weapon, damage type is melee) and only
     * when the hit actually landed (return value true).
     */
    @Inject(method = "hurt", at = @At("TAIL"))
    private void hotsteel$igniteOnHotSteelHit(class_1282 source, float amount,
                                              CallbackInfoReturnable<Boolean> cir) {
        if (!Boolean.TRUE.equals(cir.getReturnValue())) {
            return; // damage wasn't actually applied
        }
        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().method_8608()
            || !source.method_48789(class_8103.field_50104)
            || !(source.method_5526() instanceof class_1657 attacker)
            || !HOT_MELEE.contains(attacker.method_6047().method_7909())
            || self == attacker) {
            return;
        }
        self.method_20803(Math.max(self.method_20802(), IGNITE_TICKS));
    }

    /** A Hot Steel shield sets the attacker on fire when it blocks a melee hit. */
    @Inject(method = "blockUsingShield", at = @At("TAIL"))
    private void hotsteel$igniteBlockedAttacker(class_1309 attacker, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (!self.method_37908().method_8608()
            && self.method_6030().method_31574(ModItems.HOT_STEEL_SHIELD)) {
            attacker.method_20803(Math.max(attacker.method_20802(), IGNITE_TICKS));
        }
    }
}
