package com.hotsteel.entity;

import com.hotsteel.registry.ModEntities;
import com.hotsteel.registry.ModItems;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3966;

/** Arrow entity shot from a Hot Steel arrow — ignites its target on hit. */
public class HotSteelArrowEntity extends class_1665 {

    /** Fire ticks applied to a hit target (5s). */
    private static final int IGNITE_TICKS = 100;

    public HotSteelArrowEntity(class_1299<? extends HotSteelArrowEntity> type, class_1937 level) {
        super(type, level);
    }

    public HotSteelArrowEntity(class_1937 level, class_1309 shooter, class_1799 stack) {
        super(ModEntities.HOT_STEEL_ARROW, shooter, level, stack.method_7972(), class_1799.field_8037);
        this.method_7438(2.5);
        this.field_7572 = class_1666.field_7593;
    }

    @Override
    protected class_1799 method_57314() {
        return new class_1799(ModItems.HOT_STEEL_ARROW);
    }

    @Override
    protected void method_7454(class_3966 result) {
        super.method_7454(result);
        if (!this.method_37908().method_8608()
            && result.method_17782() instanceof class_1309 living) {
            living.method_20803(Math.max(living.method_20802(), IGNITE_TICKS));
        }
    }
}
