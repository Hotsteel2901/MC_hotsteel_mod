package com.hotsteel.logic;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.hotsteel.HotSteel;
import com.hotsteel.registry.ModEffects;
import com.hotsteel.registry.ModItems;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_8103;
import net.minecraft.class_8779;
import net.minecraft.server.MinecraftServer;

/**
 * Drives "Super Fire Resistance": full Hot Steel armor set + fire environment (lava / on fire)
 * grants up to 60s of full fire/lava immunity and water-like lava swimming. Also announces the
 * set becoming complete/incomplete and awards the full-set advancement.
 */
public final class SuperFireResistanceHandler {

    private SuperFireResistanceHandler() {}

    private static final int MAX_TICKS = 1200; // 60 seconds
    private static final Map<UUID, Integer> TIMER = new HashMap<>();
    private static final Set<UUID> HAD_FULL_SET = new HashSet<>();

    /** Client-safe check: driven by the auto-synced marker effect. */
    public static boolean isActive(class_1309 entity) {
        return entity.method_6059(ModEffects.SUPER_FIRE_RESISTANCE);
    }

    /**
     * Returns true if any part of the entity's bounding box intersects a lava block.
     * <p>
     * Vanilla {@link class_1309#method_5771()} only checks the fluid at the entity's eye level,
     * which causes rapid on/off toggling when the player bobs at the lava surface (water physics
     * lifts them up, eyes leave lava, physics reverts, player sinks, eyes re-enter lava, ...).
     * Checking the whole bounding box keeps the swim flag, the marker effect, and the water-physics
     * redirect stable across that bobbing so the player smoothly swims in lava like in water.
     */
    public static boolean isBodyTouchingLava(class_1309 entity) {
        if (entity.method_5771()) {
            return true; // fast path: eye-level check is enough when fully submerged
        }
        class_238 box = entity.method_5829();
        class_1937 level = entity.method_37908();
        int minX = class_3532.method_15357(box.field_1323);
        int minY = class_3532.method_15357(box.field_1322);
        int minZ = class_3532.method_15357(box.field_1321);
        int maxX = class_3532.method_15357(box.field_1320);
        int maxY = class_3532.method_15357(box.field_1325);
        int maxZ = class_3532.method_15357(box.field_1324);
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (level.method_8316(pos.method_10103(x, y, z)).method_15767(class_3486.field_15518)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static void register() {
        // Run BEFORE entity ticks so the marker effect is already present when the
        // swimming/pose mixin runs inside Player.tick(). Avoids a 1-tick "STANDING then
        // SWIMMING" snap the instant a player touches lava.
        ServerTickEvents.START_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                tick(player);
            }
        });

        // Cancel fire/lava damage the instant it would apply — no initial burn on first contact.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof class_3222 player
                && source.method_48789(class_8103.field_42246)
                && hasFullSet(player)
                && TIMER.getOrDefault(player.method_5667(), 0) < MAX_TICKS) {
                return false;
            }
            return true;
        });
    }

    private static void tick(class_3222 player) {
        UUID id = player.method_5667();
        boolean fullSet = hasFullSet(player);

        // Announce set becoming complete / incomplete.
        boolean had = HAD_FULL_SET.contains(id);
        if (fullSet && !had) {
            HAD_FULL_SET.add(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.super_fire_on").method_27692(class_124.field_1065), false);
            awardFullArmor(player);
        } else if (!fullSet && had) {
            HAD_FULL_SET.remove(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.super_fire_off").method_27692(class_124.field_1061), false);
        }

        // Fire / lava protection. Use the body-touching check (not just eye level) so the
        // effect stays granted while the player bobs at the lava surface — otherwise the
        // rapid grant/remove cycle causes the swim pose to twitch every tick.
        boolean inFire = isBodyTouchingLava(player) || player.method_5809();
        if (fullSet && inFire) {
            int elapsed = TIMER.getOrDefault(id, 0) + 1;
            TIMER.put(id, elapsed);
            if (elapsed <= MAX_TICKS) {
                player.method_5646();
                int remaining = MAX_TICKS - elapsed + 1;
                player.method_6092(new class_1293(ModEffects.SUPER_FIRE_RESISTANCE,
                    remaining, 0, true, false, true));
            } else {
                player.method_6016(ModEffects.SUPER_FIRE_RESISTANCE);
            }
        } else {
            TIMER.remove(id);
            if (player.method_6059(ModEffects.SUPER_FIRE_RESISTANCE)) {
                player.method_6016(ModEffects.SUPER_FIRE_RESISTANCE);
            }
        }
    }

    private static void awardFullArmor(class_3222 player) {
        MinecraftServer server = player.method_51469().method_8503();
        class_8779 holder = server.method_3851().method_12896(HotSteel.id("full_armor"));
        if (holder != null) {
            player.method_14236().method_12878(holder, "wear_full_set");
        }
    }

    private static boolean hasFullSet(class_1657 player) {
        return player.method_6118(class_1304.field_6169).method_31574(ModItems.HOT_STEEL_HELMET)
            && player.method_6118(class_1304.field_6174).method_31574(ModItems.HOT_STEEL_CHESTPLATE)
            && player.method_6118(class_1304.field_6172).method_31574(ModItems.HOT_STEEL_LEGGINGS)
            && player.method_6118(class_1304.field_6166).method_31574(ModItems.HOT_STEEL_BOOTS);
    }
}
