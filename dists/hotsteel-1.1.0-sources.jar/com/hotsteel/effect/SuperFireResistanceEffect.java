package com.hotsteel.effect;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

/**
 * Marker effect used only as an on-screen icon + countdown for "Super Fire Resistance".
 * The actual behaviour (fire/lava immunity, lava swimming) lives in
 * {@link com.hotsteel.logic.SuperFireResistanceHandler}.
 */
public class SuperFireResistanceEffect extends class_1291 {

    public SuperFireResistanceEffect() {
        super(class_4081.field_18271, 0xFF7A1E);
    }
}
