package com.hotsteel.datagen;

import java.util.concurrent.CompletableFuture;

import com.hotsteel.registry.ModBlocks;
import com.hotsteel.registry.ModItems;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2447;
import net.minecraft.class_2454;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;

public class ModRecipeProvider extends FabricRecipeProvider {

    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries) {
        super(output, registries);
    }

    @Override
    public void method_10419(class_8790 exporter) {
        // iron ingot -> crude steel (blast furnace)
        class_2454.method_10473(class_1856.method_8091(class_1802.field_8620),
                class_7800.field_40642, ModItems.CRUDE_STEEL, 0.7f, 100)
            .method_10469("has_iron_ingot", method_10426(class_1802.field_8620))
            .method_36443(exporter, "crude_steel_from_blasting");

        // 4 crude steel -> crude steel block
        class_2447.method_10437(class_7800.field_40634, ModBlocks.CRUDE_STEEL_BLOCK)
            .method_10439("SS")
            .method_10439("SS")
            .method_10434('S', ModItems.CRUDE_STEEL)
            .method_10429("has_crude_steel", method_10426(ModItems.CRUDE_STEEL))
            .method_10431(exporter);

        // crude steel block -> steel ingot (blast furnace)
        class_2454.method_10473(class_1856.method_8091(ModBlocks.CRUDE_STEEL_BLOCK),
                class_7800.field_40642, ModItems.STEEL_INGOT, 1.0f, 100)
            .method_10469("has_crude_steel_block", method_10426(ModBlocks.CRUDE_STEEL_BLOCK))
            .method_36443(exporter, "steel_ingot_from_blasting");

        // ---- Equipment from hot steel ingot ----
        // Armor
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_HELMET)
            .method_10439("III").method_10439("I I")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_CHESTPLATE)
            .method_10439("I I").method_10439("III").method_10439("III")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_LEGGINGS)
            .method_10439("III").method_10439("I I").method_10439("I I")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_BOOTS)
            .method_10439("I I").method_10439("I I")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // Tools & weapons
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_SWORD)
            .method_10439("I").method_10439("I").method_10439("S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_KNIFE)
            .method_10439("I").method_10439("S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_PICKAXE)
            .method_10439("III").method_10439(" S ").method_10439(" S ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_AXE)
            .method_10439("II").method_10439("IS").method_10439(" S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_SHOVEL)
            .method_10439("I").method_10439("S").method_10439("S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_HOE)
            .method_10439("II").method_10439(" S").method_10439(" S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // Ranged / special
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_BOW)
            .method_10439(" IR").method_10439("I R").method_10439(" IR")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('R', class_1802.field_8276)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_CROSSBOW)
            .method_10439("ITI").method_10439("RSR").method_10439(" I ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8366)
            .method_10434('T', class_1802.field_8600).method_10434('R', class_1802.field_8276)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_TRIDENT)
            .method_10439("III").method_10439(" I ").method_10439(" I ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_SHIELD)
            .method_10439("I I").method_10439("III").method_10439(" I ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
    }
}
