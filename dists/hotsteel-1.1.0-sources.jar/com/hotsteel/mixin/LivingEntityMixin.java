package com.hotsteel.mixin;

import com.hotsteel.logic.SuperFireResistanceHandler;
import com.hotsteel.registry.ModItems;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    /**
     * While Super Fire Resistance is active, treat lava as water inside {@code travel()} so the
     * player swims through lava with water physics instead of the sluggish lava branch.
     * Uses the body-touching-lava check so water physics stays applied while the player bobs at
     * the lava surface — keeps them moving smoothly instead of sink-rise-sink-rise cycling.
     */
    @Redirect(
        method = "travel",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;isInWater()Z"))
    private boolean hotsteel$lavaAsWater(class_1309 self) {
        if (self instanceof class_1657
            && SuperFireResistanceHandler.isActive(self)
            && SuperFireResistanceHandler.isBodyTouchingLava(self)) {
            return true;
        }
        return self.method_5799();
    }

    /**
     * While Super Fire Resistance is active in lava, drive the swim-amount interpolation from the
     * freshly-set swimming flag instead of {@code hasPose(SWIMMING)}. Vanilla calls
     * {@code updateSwimAmount()} BEFORE {@code updatePlayerPose()} in the tick, so the pose lags
     * the flag by one tick — without this redirect, the arms lower when you start sprinting and
     * keep rising the tick you stop sprinting, which reads as a twitch at every transition.
     */
    @Redirect(
        method = "updateSwimAmount",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;isVisuallySwimming()Z"))
    private boolean hotsteel$lavaSwimAmountUseFlag(class_1309 self) {
        if (self instanceof class_1657 player
            && SuperFireResistanceHandler.isActive(self)
            && SuperFireResistanceHandler.isBodyTouchingLava(self)) {
            return player.method_5681();
        }
        return self.method_20232();
    }

    /** A Hot Steel shield sets the attacker on fire when it blocks a melee hit. */
    @Inject(method = "blockUsingShield", at = @At("TAIL"))
    private void hotsteel$igniteBlockedAttacker(class_1309 attacker, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (!self.method_37908().method_8608()
            && self.method_6030().method_31574(ModItems.HOT_STEEL_SHIELD)) {
            attacker.method_5639(5.0f);
        }
    }
}
