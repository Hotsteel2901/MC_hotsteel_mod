package com.hotsteel.mixin;

import com.hotsteel.registry.ModItems;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4770;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Turns a dropped Steel Ingot into a Hot Steel Ingot by heating it:
 * in lava it takes ~5s (100 ticks); in fire it takes twice as long (~10s / 200 ticks).
 */
@Mixin(class_1542.class)
public abstract class ItemEntityMixin {

    @Unique
    private static final int HEAT_THRESHOLD = 200;

    @Unique
    private int hotsteel$heatProgress = 0;

    @Inject(method = "tick", at = @At("TAIL"))
    private void hotsteel$heatSteel(CallbackInfo ci) {
        class_1542 self = (class_1542) (Object) this;
        if (self.method_37908().method_8608()) {
            return;
        }
        class_1799 stack = self.method_6983();
        if (!stack.method_31574(ModItems.STEEL_INGOT)) {
            hotsteel$heatProgress = 0;
            return;
        }

        int add = 0;
        if (self.method_5771()) {
            add = 2;                              // lava: full speed -> 100 ticks
        } else if (hotsteel$inFire(self)) {
            add = 1;                              // fire: half speed -> 200 ticks
        }

        if (add > 0) {
            hotsteel$heatProgress += add;
            if (hotsteel$heatProgress >= HEAT_THRESHOLD) {
                hotsteel$heatProgress = 0;
                self.method_6979(new class_1799(ModItems.HOT_STEEL_INGOT, stack.method_7947()));
                self.method_37908().method_43128(null, self.method_23317(), self.method_23318(), self.method_23321(),
                    class_3417.field_15102, class_3419.field_15245, 0.6f, 1.4f);
                if (self.method_37908() instanceof class_3218 serverLevel) {
                    serverLevel.method_14199(class_2398.field_11239,
                        self.method_23317(), self.method_23318() + 0.2, self.method_23321(), 10, 0.15, 0.15, 0.15, 0.0);
                }
            }
        } else {
            hotsteel$heatProgress = 0;
        }
    }

    @Unique
    private boolean hotsteel$inFire(class_1542 self) {
        return self.method_37908().method_8320(self.method_24515()).method_26204() instanceof class_4770;
    }
}
