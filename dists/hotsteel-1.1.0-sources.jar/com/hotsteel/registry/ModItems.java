package com.hotsteel.registry;

import com.hotsteel.HotSteel;
import com.hotsteel.item.HotSteelBowItem;
import com.hotsteel.item.HotSteelCrossbowItem;
import com.hotsteel.item.HotSteelShieldItem;
import com.hotsteel.item.HotSteelTridentItem;
import com.hotsteel.item.KnifeItem;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public final class ModItems {

    private ModItems() {}

    // ---- Materials ----
    public static final class_1792 CRUDE_STEEL = register("crude_steel",
        new class_1792(new class_1792.class_1793()));

    public static final class_1792 STEEL_INGOT = register("steel_ingot",
        new class_1792(new class_1792.class_1793().method_24359()));

    public static final class_1792 HOT_STEEL_INGOT = register("hot_steel_ingot",
        new class_1792(new class_1792.class_1793().method_24359()));

    // ---- Armor ----
    public static final class_1792 HOT_STEEL_HELMET = register("hot_steel_helmet",
        new class_1738(ModMaterials.HOT_STEEL_ARMOR, class_1738.class_8051.field_41934,
            new class_1792.class_1793().method_24359()
                .method_7895(class_1738.class_8051.field_41934.method_56690(ModMaterials.ARMOR_DURABILITY_MULT))));

    public static final class_1792 HOT_STEEL_CHESTPLATE = register("hot_steel_chestplate",
        new class_1738(ModMaterials.HOT_STEEL_ARMOR, class_1738.class_8051.field_41935,
            new class_1792.class_1793().method_24359()
                .method_7895(class_1738.class_8051.field_41935.method_56690(ModMaterials.ARMOR_DURABILITY_MULT))));

    public static final class_1792 HOT_STEEL_LEGGINGS = register("hot_steel_leggings",
        new class_1738(ModMaterials.HOT_STEEL_ARMOR, class_1738.class_8051.field_41936,
            new class_1792.class_1793().method_24359()
                .method_7895(class_1738.class_8051.field_41936.method_56690(ModMaterials.ARMOR_DURABILITY_MULT))));

    public static final class_1792 HOT_STEEL_BOOTS = register("hot_steel_boots",
        new class_1738(ModMaterials.HOT_STEEL_ARMOR, class_1738.class_8051.field_41937,
            new class_1792.class_1793().method_24359()
                .method_7895(class_1738.class_8051.field_41937.method_56690(ModMaterials.ARMOR_DURABILITY_MULT))));

    // ---- Tools ----
    public static final class_1792 HOT_STEEL_SWORD = register("hot_steel_sword",
        new class_1829(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1829.method_57394(ModMaterials.HotSteelTier.INSTANCE, 4, -2.4f))));

    public static final class_1792 HOT_STEEL_PICKAXE = register("hot_steel_pickaxe",
        new class_1810(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1810.method_57346(ModMaterials.HotSteelTier.INSTANCE, 1.0f, -2.8f))));

    public static final class_1792 HOT_STEEL_AXE = register("hot_steel_axe",
        new class_1743(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1743.method_57346(ModMaterials.HotSteelTier.INSTANCE, 6.0f, -3.0f))));

    public static final class_1792 HOT_STEEL_SHOVEL = register("hot_steel_shovel",
        new class_1821(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1821.method_57346(ModMaterials.HotSteelTier.INSTANCE, 1.5f, -3.0f))));

    public static final class_1792 HOT_STEEL_HOE = register("hot_steel_hoe",
        new class_1794(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1794.method_57346(ModMaterials.HotSteelTier.INSTANCE, -4.0f, 0.0f))));

    // ---- New weapon: knife (light & fast) ----
    public static final class_1792 HOT_STEEL_KNIFE = register("hot_steel_knife",
        new KnifeItem(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1829.method_57394(ModMaterials.HotSteelTier.INSTANCE, 1, -2.0f))));

    // ---- Ranged / special ----
    public static final class_1792 HOT_STEEL_BOW = register("hot_steel_bow",
        new HotSteelBowItem(new class_1792.class_1793().method_24359().method_7895(1000)));

    public static final class_1792 HOT_STEEL_CROSSBOW = register("hot_steel_crossbow",
        new HotSteelCrossbowItem(new class_1792.class_1793().method_24359().method_7895(1200)));

    public static final class_1792 HOT_STEEL_TRIDENT = register("hot_steel_trident",
        new HotSteelTridentItem(new class_1792.class_1793().method_24359().method_7895(500)
            .method_57348(HotSteelTridentItem.createAttributes())));

    public static final class_1792 HOT_STEEL_SHIELD = register("hot_steel_shield",
        new HotSteelShieldItem(new class_1792.class_1793().method_24359().method_7895(500)));

    private static class_1792 register(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, HotSteel.id(name), item);
    }

    public static void register() {
        HotSteel.LOGGER.info("Registering Hot Steel items");
    }
}
