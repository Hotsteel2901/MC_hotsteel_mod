package com.hotsteel.registry;

import com.hotsteel.HotSteel;
import com.hotsteel.effect.SuperFireResistanceEffect;
import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public final class ModEffects {

    private ModEffects() {}

    public static final class_6880<class_1291> SUPER_FIRE_RESISTANCE = class_2378.method_47985(
        class_7923.field_41174,
        HotSteel.id("super_fire_resistance"),
        new SuperFireResistanceEffect());

    public static void register() {
        HotSteel.LOGGER.info("Registering Hot Steel effects");
    }
}
