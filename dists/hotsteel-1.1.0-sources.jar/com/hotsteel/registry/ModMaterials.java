package com.hotsteel.registry;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import com.hotsteel.HotSteel;

public final class ModMaterials {

    private ModMaterials() {}

    /** Tool tier: stronger than netherite. */
    public enum HotSteelTier implements class_1832 {
        INSTANCE;

        @Override public int method_8025() { return 2800; }
        @Override public float method_8027() { return 15.0f; }
        @Override public float method_8028() { return 5.0f; }
        @Override public class_6862<class_2248> method_58419() { return class_3481.field_49925; }
        @Override public int method_8026() { return 18; }
        @Override public class_1856 method_8023() { return class_1856.method_8091(ModItems.HOT_STEEL_INGOT); }
    }

    /** Armor durability multiplier (netherite is 37). */
    public static final int ARMOR_DURABILITY_MULT = 45;

    public static final class_6880<class_1741> HOT_STEEL_ARMOR = register("hot_steel",
        class_156.method_654(new EnumMap<>(class_1738.class_8051.class), m -> {
            m.put(class_1738.class_8051.field_41937, 4);
            m.put(class_1738.class_8051.field_41936, 7);
            m.put(class_1738.class_8051.field_41935, 9);
            m.put(class_1738.class_8051.field_41934, 4);
        }),
        18,
        class_3417.field_21866,
        4.0f,
        0.15f,
        () -> class_1856.method_8091(ModItems.HOT_STEEL_INGOT));

    private static class_6880<class_1741> register(String name,
                                                  Map<class_1738.class_8051, Integer> defense,
                                                  int enchantmentValue,
                                                  class_6880<class_3414> equipSound,
                                                  float toughness,
                                                  float knockbackResistance,
                                                  Supplier<class_1856> repairIngredient) {
        class_2960 loc = HotSteel.id(name);
        List<class_1741.class_9196> layers = List.of(new class_1741.class_9196(loc));
        class_1741 material = new class_1741(defense, enchantmentValue, equipSound,
            repairIngredient, layers, toughness, knockbackResistance);
        return class_2378.method_47985(class_7923.field_48976, loc, material);
    }

    public static void init() {
        HotSteel.LOGGER.info("Registering Hot Steel materials");
    }
}
