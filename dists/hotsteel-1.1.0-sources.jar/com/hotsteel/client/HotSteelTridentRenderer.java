package com.hotsteel.client;

import com.hotsteel.HotSteel;
import com.hotsteel.entity.HotSteelTridentEntity;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_613;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import net.minecraft.class_918;

public class HotSteelTridentRenderer extends class_897<HotSteelTridentEntity> {

    public static final class_2960 TEXTURE = HotSteel.id("textures/entity/hot_steel_trident.png");

    private final class_613 model;

    public HotSteelTridentRenderer(class_5617.class_5618 context) {
        super(context);
        this.model = new class_613(context.method_32167(class_5602.field_27668));
    }

    @Override
    public void render(HotSteelTridentEntity entity, float entityYaw, float partialTick,
                       class_4587 poseStack, class_4597 buffer, int packedLight) {
        poseStack.method_22903();
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(class_3532.method_16439(partialTick, entity.field_5982, entity.method_36454()) - 90.0f));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(class_3532.method_16439(partialTick, entity.field_6004, entity.method_36455()) + 90.0f));
        class_4588 vc = class_918.method_29711(buffer,
            this.model.method_23500(this.getTextureLocation(entity)), false, entity.isFoil());
        this.model.method_60879(poseStack, vc, packedLight, class_4608.field_21444);
        poseStack.method_22909();
        super.method_3936(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }

    @Override
    public class_2960 getTextureLocation(HotSteelTridentEntity entity) {
        return TEXTURE;
    }
}
