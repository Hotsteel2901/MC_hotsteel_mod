package com.hotsteel.item;

import net.minecraft.class_1829;
import net.minecraft.class_1832;

/** A light, fast blade: lower damage than a sword but quicker swing. */
public class KnifeItem extends class_1829 {
    public KnifeItem(class_1832 tier, class_1793 properties) {
        super(tier, properties);
    }
}
