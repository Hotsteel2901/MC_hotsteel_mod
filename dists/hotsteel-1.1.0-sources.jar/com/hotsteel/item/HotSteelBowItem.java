package com.hotsteel.item;

import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_1744;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;

/** Hot Steel bow: sturdier than vanilla and its arrows hit harder. */
public class HotSteelBowItem extends class_1753 {

    public HotSteelBowItem(class_1793 properties) {
        super(properties);
    }

    @Override
    protected class_1676 method_57344(class_1937 level, class_1309 shooter, class_1799 weapon, class_1799 ammo, boolean crit) {
        class_1744 arrowItem = ammo.method_7909() instanceof class_1744 ai ? ai : (class_1744) class_1802.field_8107;
        class_1665 arrow = arrowItem.method_7702(level, ammo, shooter, weapon);
        if (crit) {
            arrow.method_7439(true);
        }
        arrow.method_7438(arrow.method_7448() + 1.5);
        return arrow;
    }
}
