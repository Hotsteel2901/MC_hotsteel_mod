package com.hotsteel.item;

import com.hotsteel.entity.HotSteelTridentEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1657;
import net.minecraft.class_1665;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_5134;
import net.minecraft.class_9274;
import net.minecraft.class_9285;

/** Hot Steel trident: stronger melee and throw than the vanilla trident (no riptide/loyalty). */
public class HotSteelTridentItem extends class_1792 {

    public HotSteelTridentItem(class_1793 properties) {
        super(properties);
    }

    public static class_9285 createAttributes() {
        return class_9285.method_57480()
            .method_57487(class_5134.field_23721,
                new class_1322(field_8006, 9.0, class_1322.class_1323.field_6328),
                class_9274.field_49217)
            .method_57487(class_5134.field_23723,
                new class_1322(field_8001, -2.9, class_1322.class_1323.field_6328),
                class_9274.field_49217)
            .method_57486();
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8951;
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 entity) {
        return 72000;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (stack.method_7919() >= stack.method_7936() - 1) {
            return class_1271.method_22431(stack);
        }
        player.method_6019(hand);
        return class_1271.method_22428(stack);
    }

    @Override
    public void method_7840(class_1799 stack, class_1937 level, class_1309 entity, int timeLeft) {
        if (!(entity instanceof class_1657 player)) {
            return;
        }
        int used = this.method_7881(stack, entity) - timeLeft;
        if (used < 10) {
            return;
        }
        if (!level.field_9236) {
            class_1304 slot = entity.method_6058() == class_1268.field_5808
                ? class_1304.field_6173 : class_1304.field_6171;
            stack.method_7970(1, entity, slot);

            HotSteelTridentEntity trident = new HotSteelTridentEntity(level, player, stack.method_7972());
            trident.method_24919(player, player.method_36455(), player.method_36454(), 0.0f, 2.5f, 1.0f);
            if (player.method_31549().field_7477) {
                trident.field_7572 = class_1665.class_1666.field_7594;
            }
            level.method_8649(trident);
            level.method_43128(null, trident.method_23317(), trident.method_23318(), trident.method_23321(),
                class_3417.field_15001.comp_349(), class_3419.field_15248, 1.0f, 1.0f);
            if (!player.method_31549().field_7477) {
                player.method_31548().method_7378(stack);
            }
        }
        player.method_7259(class_3468.field_15372.method_14956(this));
    }
}
