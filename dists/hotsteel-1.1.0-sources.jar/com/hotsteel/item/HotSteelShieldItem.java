package com.hotsteel.item;

import net.minecraft.class_1819;

/** Hot Steel shield: higher durability, fireproof. */
public class HotSteelShieldItem extends class_1819 {
    public HotSteelShieldItem(class_1793 properties) {
        super(properties);
    }
}
