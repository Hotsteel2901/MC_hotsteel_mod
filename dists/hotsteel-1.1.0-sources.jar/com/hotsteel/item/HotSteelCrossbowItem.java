package com.hotsteel.item;

import net.minecraft.class_1764;

/** Hot Steel crossbow: higher durability than vanilla. */
public class HotSteelCrossbowItem extends class_1764 {
    public HotSteelCrossbowItem(class_1793 properties) {
        super(properties);
    }
}
