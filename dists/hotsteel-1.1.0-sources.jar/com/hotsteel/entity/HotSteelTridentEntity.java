package com.hotsteel.entity;

import com.hotsteel.registry.ModEntities;
import com.hotsteel.registry.ModItems;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

/** Thrown Hot Steel trident. Behaves like an arrow that drops the trident on landing. */
public class HotSteelTridentEntity extends class_1665 {

    public HotSteelTridentEntity(class_1299<? extends HotSteelTridentEntity> type, class_1937 level) {
        super(type, level);
    }

    public HotSteelTridentEntity(class_1937 level, class_1309 shooter, class_1799 stack) {
        super(ModEntities.HOT_STEEL_TRIDENT, shooter, level, stack.method_7972(), null);
        this.method_7438(4.0);
        this.field_7572 = class_1666.field_7593;
    }

    @Override
    protected class_1799 method_57314() {
        return new class_1799(ModItems.HOT_STEEL_TRIDENT);
    }

    public boolean isFoil() {
        return false;
    }
}
