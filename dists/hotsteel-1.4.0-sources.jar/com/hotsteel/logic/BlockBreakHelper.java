package com.hotsteel.logic;

import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/** Shared helper for breaking blocks as a player: spawns drops and charges tool durability. */
public final class BlockBreakHelper {

    private BlockBreakHelper() {}

    public static void breakBlock(class_1937 level, class_2338 pos, class_1657 player, class_1799 tool) {
        class_2680 state = level.method_8320(pos);
        if (state.method_26215()) {
            return;
        }
        if (level instanceof class_3218 serverLevel) {
            List<class_1799> drops = class_2248.method_9609(state, serverLevel, pos,
                level.method_8321(pos), player, tool);
            for (class_1799 drop : drops) {
                class_2248.method_9577(level, pos, drop);
            }
        }
        level.method_22352(pos, false);
        if (!player.method_31549().field_7477) {
            tool.method_7970(1, player, class_1304.field_6173);
        }
    }
}
