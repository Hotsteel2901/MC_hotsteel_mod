package com.hotsteel.logic;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.hotsteel.registry.ModBlocks;
import com.hotsteel.registry.ModEffects;
import com.hotsteel.registry.ModItems;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_8103;

/**
 * Drives the Hot Steel armor set bonuses and the Super Fire Resistance potion:
 * <ul>
 *   <li><b>2+ pieces — Flame Ward:</b> immune to fire damage (fire, magma, fireballs…),
 *       but lava still hurts without the full set.</li>
 *   <li><b>4 pieces + fire environment — Super Fire Resistance:</b> up to 60s of full
 *       fire/lava immunity plus water-like lava movement (Dolphin's Grace speed boost),
 *       with a HUD countdown effect. With the boots, the player can also walk ON lava.</li>
 *   <li><b>Potion of Super Fire Resistance:</b> grants the same immunity + lava movement
 *       without any armor (managed so we never strip a potion-applied effect).</li>
 * </ul>
 */
public final class SuperFireResistanceHandler {

    private SuperFireResistanceHandler() {}

    private static final int MAX_TICKS = 1200; // 60 seconds
    private static final Map<UUID, Integer> TIMER = new HashMap<>();
    private static final Set<UUID> HAD_FULL_SET = new HashSet<>();
    private static final Set<UUID> HAD_TWO_SET = new HashSet<>();
    /** Players whose SUPER_FIRE_RESISTANCE effect was applied by us (armor). */
    private static final Set<UUID> MANAGED = new HashSet<>();

    /** Client-safe check: driven by the auto-synced marker effect. */
    public static boolean isActive(class_1309 entity) {
        return entity.method_6059(ModEffects.SUPER_FIRE_RESISTANCE);
    }

    /**
     * Returns true if any part of the entity's bounding box intersects a lava block.
     * Checks the whole bounding box (not just eye level) so the effect and speed
     * boost stay stable across bobbing at the lava surface.
     */
    public static boolean isBodyTouchingLava(class_1309 entity) {
        if (entity.method_5771()) {
            return true; // fast path: eye-level check is enough when fully submerged
        }
        class_238 box = entity.method_5829();
        class_1937 level = entity.method_37908();
        int minX = class_3532.method_15357(box.field_1323);
        int minY = class_3532.method_15357(box.field_1322);
        int minZ = class_3532.method_15357(box.field_1321);
        int maxX = class_3532.method_15357(box.field_1320);
        int maxY = class_3532.method_15357(box.field_1325);
        int maxZ = class_3532.method_15357(box.field_1324);
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (level.method_8316(pos.method_10103(x, y, z)).method_15767(class_3486.field_15518)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** Top Y (block coordinate) of the highest lava block inside the entity's AABB, or null if none. */
    private static Integer lavaSurfaceY(class_1309 entity) {
        class_238 box = entity.method_5829();
        class_1937 level = entity.method_37908();
        int top = Integer.MIN_VALUE;
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int y = class_3532.method_15357(box.field_1322); y <= class_3532.method_15357(box.field_1325); y++) {
            for (int x = class_3532.method_15357(box.field_1323); x <= class_3532.method_15357(box.field_1320); x++) {
                for (int z = class_3532.method_15357(box.field_1321); z <= class_3532.method_15357(box.field_1324); z++) {
                    if (level.method_8316(pos.method_10103(x, y, z)).method_15767(class_3486.field_15518)) {
                        top = Math.max(top, y);
                    }
                }
            }
        }
        return top == Integer.MIN_VALUE ? null : top;
    }

    public static void register() {
        ServerTickEvents.START_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                tick(player);
            }
        });

        // Cancel fire/lava damage:
        //  - 2+ pieces: immune to all fire-tag damage EXCEPT direct lava (keeps the 4-piece meaningful).
        //  - full set (timer active) OR having the Super Fire Resistance effect (armor or potion):
        //    full immunity including lava.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof class_3222 player && source.method_48789(class_8103.field_42246)) {
                // Blocking with a Hot Steel shield makes you fully fireproof and
                // instantly puts out any fire on you.
                if (player.method_6039()
                    && player.method_6030().method_31574(ModItems.HOT_STEEL_SHIELD)) {
                    player.method_5646();
                    return false;
                }
                int pieces = countPieces(player);
                boolean hasSuperEffect = player.method_6059(ModEffects.SUPER_FIRE_RESISTANCE);
                boolean fullSuper = hasSuperEffect
                    || (pieces >= 4 && TIMER.getOrDefault(player.method_5667(), 0) < MAX_TICKS);
                boolean flameWard = pieces >= 2 && !"lava".equals(source.method_48792().comp_1242());
                if (fullSuper || flameWard) {
                    return false;
                }
            }
            return true;
        });
    }

    private static void tick(class_3222 player) {
        UUID id = player.method_5667();
        int pieces = countPieces(player);

        boolean hadTwo = HAD_TWO_SET.contains(id);
        if (pieces >= 2 && !hadTwo) {
            HAD_TWO_SET.add(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.flame_ward_on").method_27692(class_124.field_1065),
                false);
            AdvancementHelper.award(player, "set_bonus_2", "wear_two_pieces");
        } else if (pieces < 2 && hadTwo) {
            HAD_TWO_SET.remove(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.flame_ward_off").method_27692(class_124.field_1061),
                false);
        }

        boolean fullSet = pieces >= 4;
        boolean hadFull = HAD_FULL_SET.contains(id);
        if (fullSet && !hadFull) {
            HAD_FULL_SET.add(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.super_fire_on").method_27692(class_124.field_1065),
                false);
            AdvancementHelper.award(player, "full_armor", "wear_full_set");
        } else if (!fullSet && hadFull) {
            HAD_FULL_SET.remove(id);
            player.method_7353(
                class_2561.method_43471("message.hotsteel.super_fire_off").method_27692(class_124.field_1061),
                false);
        }

        // Armor-driven Super Fire Resistance timer.
        boolean inLava = isBodyTouchingLava(player);
        boolean inFire = inLava || player.method_5809();
        if (fullSet && inFire) {
            int elapsed = TIMER.getOrDefault(id, 0) + 1;
            TIMER.put(id, elapsed);
            if (elapsed <= MAX_TICKS) {
                player.method_5646();
                MANAGED.add(id);
                int remaining = MAX_TICKS - elapsed + 1;
                class_1293 existing = player.method_6112(ModEffects.SUPER_FIRE_RESISTANCE);
                // Don't overwrite a strong potion with the weaker armor-level effect.
                boolean keepStrong = existing != null && existing.method_5578() >= 1;
                if (!keepStrong) {
                    player.method_6092(new class_1293(ModEffects.SUPER_FIRE_RESISTANCE,
                        remaining, 0, true, false, true));
                }
            } else {
                MANAGED.remove(id);
                player.method_6016(ModEffects.SUPER_FIRE_RESISTANCE);
            }
        } else {
            TIMER.remove(id);
            if (MANAGED.remove(id)) {
                if (player.method_6059(ModEffects.SUPER_FIRE_RESISTANCE)) {
                    player.method_6016(ModEffects.SUPER_FIRE_RESISTANCE);
                }
            }
        }

        // Lava speed boost is driven by the actual effect (armor OR potion):
        // Dolphin's Grace amplifier = 1 + effect level, so the Strong potion is faster.
        class_1293 superEffect = player.method_6112(ModEffects.SUPER_FIRE_RESISTANCE);
        if (superEffect != null && inLava) {
            int amp = superEffect.method_5578();
            player.method_6092(new class_1293(class_1294.field_5900,
                superEffect.method_5584(), 1 + amp, false, false, false));
        } else if (superEffect == null) {
            player.method_6016(class_1294.field_5900);
        }

        // Lava Walker: full set + boots lets the player walk ON the lava surface.
        if (fullSet && isActive(player) && inLava
            && player.method_6118(class_1304.field_6166).method_31574(ModItems.HOT_STEEL_BOOTS)) {
            Integer top = lavaSurfaceY(player);
            if (top != null) {
                double surface = top + 1.0;
                boolean headAboveSurface = player.method_23318() + player.method_17682() - 0.3 > surface;
                if (headAboveSurface) {
                    // stop sinking; stay on top of the lava
                    if (player.method_18798().field_1351 < 0) {
                        player.method_18800(player.method_18798().field_1352, 0.0, player.method_18798().field_1350);
                    }
                    if (player.method_23318() <= surface) {
                        player.method_24830(true);
                    }
                }
            }
        }

        // Molten Aura: with the full set in lava, nearby mobs are scorched.
        if (fullSet && isActive(player) && inLava) {
            class_238 aura = player.method_5829().method_1014(3.0);
            for (class_1309 target : player.method_37908().method_18467(class_1309.class, aura)) {
                if (target != player && !target.method_5753()) {
                    target.method_20803(Math.max(target.method_20802(), 40));
                }
            }
        }

        // Auto-Repair: with the full set in lava, worn Hot Steel gear repairs itself
        // (1 durability per 4 ticks).
        if (fullSet && inLava) {
            for (class_1304 slot : class_1304.values()) {
                class_1799 stack = player.method_6118(slot);
                if (isHotSteelGear(stack) && stack.method_7986()
                    && player.field_6012 % 4 == 0) {
                    stack.method_7974(stack.method_7919() - 1);
                }
            }
        }

        // Warm Hearth: standing near a Block of Hot Steel grants passive Fire
        // Resistance (refreshed every tick while close, fades 3s after leaving).
        if (nearHotSteelBlock(player)) {
            if (!player.method_6059(class_1294.field_5918)) {
                player.method_6092(new class_1293(class_1294.field_5918,
                    60, 0, false, false, false));
            }
        }
    }

    /** True if the player is within a couple of blocks of a Block of Hot Steel. */
    private static boolean nearHotSteelBlock(class_1657 player) {
        class_1937 level = player.method_37908();
        class_2338 center = player.method_24515();
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (level.method_8320(
                        pos.method_10103(center.method_10263() + dx, center.method_10264() + dy, center.method_10260() + dz))
                        .method_27852(ModBlocks.HOT_STEEL_BLOCK)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** Hot Steel gear that self-repairs while the full set is worn in lava. */
    private static final java.util.Set<net.minecraft.class_1792> HOT_STEEL_GEAR =
        java.util.Set.of(
            ModItems.HOT_STEEL_HELMET, ModItems.HOT_STEEL_CHESTPLATE,
            ModItems.HOT_STEEL_LEGGINGS, ModItems.HOT_STEEL_BOOTS,
            ModItems.HOT_STEEL_SWORD, ModItems.HOT_STEEL_MACE, ModItems.HOT_STEEL_KNIFE,
            ModItems.HOT_STEEL_SICKLE, ModItems.HOT_STEEL_PICKAXE, ModItems.HOT_STEEL_AXE,
            ModItems.HOT_STEEL_SHOVEL, ModItems.HOT_STEEL_HOE, ModItems.HOT_STEEL_BOW,
            ModItems.HOT_STEEL_CROSSBOW, ModItems.HOT_STEEL_TRIDENT, ModItems.HOT_STEEL_SHIELD);

    /** True if the stack is one of the mod's repairable Hot Steel items. */
    private static boolean isHotSteelGear(class_1799 stack) {
        return HOT_STEEL_GEAR.contains(stack.method_7909());
    }

    /** Number of Hot Steel armor pieces currently worn (0–4). */
    private static int countPieces(class_1657 player) {
        int count = 0;
        if (player.method_6118(class_1304.field_6169).method_31574(ModItems.HOT_STEEL_HELMET)) count++;
        if (player.method_6118(class_1304.field_6174).method_31574(ModItems.HOT_STEEL_CHESTPLATE)) count++;
        if (player.method_6118(class_1304.field_6172).method_31574(ModItems.HOT_STEEL_LEGGINGS)) count++;
        if (player.method_6118(class_1304.field_6166).method_31574(ModItems.HOT_STEEL_BOOTS)) count++;
        return count;
    }
}
