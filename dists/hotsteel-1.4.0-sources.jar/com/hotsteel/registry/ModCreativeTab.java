package com.hotsteel.registry;

import com.hotsteel.HotSteel;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ModCreativeTab {

    private ModCreativeTab() {}

    public static final class_5321<class_1761> HOT_STEEL_TAB_KEY =
        class_5321.method_29179(class_7924.field_44688, HotSteel.id("hot_steel"));

    public static final class_1761 HOT_STEEL_TAB = class_2378.method_39197(
        class_7923.field_44687,
        HOT_STEEL_TAB_KEY,
        FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModItems.HOT_STEEL_INGOT))
            .method_47321(class_2561.method_43471("itemGroup.hotsteel.hot_steel"))
            .method_47317((params, output) -> {
                output.method_45421(ModItems.CRUDE_STEEL);
                output.method_45421(ModBlocks.CRUDE_STEEL_BLOCK);
                output.method_45421(ModItems.STEEL_INGOT);
                output.method_45421(ModBlocks.STEEL_BLOCK);
                output.method_45421(ModItems.HOT_STEEL_INGOT);
                output.method_45421(ModItems.HOT_STEEL_NUGGET);
                output.method_45421(ModItems.MOLTEN_CORE);
                output.method_45421(ModItems.HOT_STEEL_APPLE);
                output.method_45421(ModBlocks.HOT_STEEL_BLOCK);
                output.method_45421(ModBlocks.HOT_STEEL_STAIRS);
                output.method_45421(ModBlocks.HOT_STEEL_SLAB);
                output.method_45421(ModBlocks.HOT_STEEL_WALL);
                output.method_45421(ModBlocks.HOT_STEEL_BRICKS);
                output.method_45421(ModBlocks.HOT_STEEL_DOOR);
                output.method_45421(ModBlocks.HOT_STEEL_TRAPDOOR);
                output.method_45421(ModBlocks.HOT_STEEL_FENCE);
                output.method_45421(ModBlocks.HOT_STEEL_CHAIN);
                output.method_45421(ModBlocks.HOT_STEEL_LADDER);
                output.method_45421(ModBlocks.HOT_STEEL_PRESSURE_PLATE);
                output.method_45421(ModBlocks.HOT_STEEL_FORGE);
                output.method_45421(ModBlocks.HOT_STEEL_SMELTER);
                output.method_45421(ModBlocks.HOT_STEEL_LANTERN);

                output.method_45421(ModItems.HOT_STEEL_HELMET);
                output.method_45421(ModItems.HOT_STEEL_CHESTPLATE);
                output.method_45421(ModItems.HOT_STEEL_LEGGINGS);
                output.method_45421(ModItems.HOT_STEEL_BOOTS);

                output.method_45421(ModItems.HOT_STEEL_SWORD);
                output.method_45421(ModItems.HOT_STEEL_MACE);
                output.method_45421(ModItems.HOT_STEEL_KNIFE);
                output.method_45421(ModItems.HOT_STEEL_SICKLE);
                output.method_45421(ModItems.HOT_STEEL_PICKAXE);
                output.method_45421(ModItems.HOT_STEEL_AXE);
                output.method_45421(ModItems.HOT_STEEL_SHOVEL);
                output.method_45421(ModItems.HOT_STEEL_HOE);
                output.method_45421(ModItems.HOT_STEEL_PAXEL);

                output.method_45421(ModItems.HOT_STEEL_BOW);
                output.method_45421(ModItems.HOT_STEEL_CROSSBOW);
                output.method_45421(ModItems.HOT_STEEL_TRIDENT);
                output.method_45421(ModItems.HOT_STEEL_SHIELD);
                output.method_45421(ModItems.HOT_STEEL_FISHING_ROD);
                output.method_45421(ModItems.HOT_STEEL_ARROW);
                output.method_45421(ModItems.HOT_STEEL_FIREBALL);
                output.method_45421(ModItems.LAVA_BOTTLE);
                output.method_45421(ModItems.LAVA_GOLEM_SPAWN_EGG);
                output.method_45421(ModItems.FIRE_WRAITH_SPAWN_EGG);
            })
            .method_47324());

    public static void register() {
        HotSteel.LOGGER.info("Registering Hot Steel creative tab");
    }
}
