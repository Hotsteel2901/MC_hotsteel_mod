package com.hotsteel.registry;

import com.hotsteel.HotSteel;
import com.hotsteel.block.HotSteelSmelterBlockEntity;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_7923;

public final class ModBlockEntities {

    private ModBlockEntities() {}

    public static final class_2591<HotSteelSmelterBlockEntity> HOT_STEEL_SMELTER =
        class_2378.method_10230(
            class_7923.field_41181,
            HotSteel.id("hot_steel_smelter"),
            class_2591.class_2592.method_20528(HotSteelSmelterBlockEntity::new, ModBlocks.HOT_STEEL_SMELTER)
                .method_11034(null));

    public static void register() {
        HotSteel.LOGGER.info("Registering Hot Steel block entities");
    }
}
