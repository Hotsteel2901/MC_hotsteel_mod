package com.hotsteel.registry;

import com.hotsteel.HotSteel;
import com.hotsteel.block.HotSteelForgeBlock;
import com.hotsteel.block.HotSteelLanternBlock;
import com.hotsteel.block.HotSteelPressurePlateBlock;
import com.hotsteel.block.HotSteelSmelterBlock;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2354;
import net.minecraft.class_2378;
import net.minecraft.class_2399;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5172;
import net.minecraft.class_7923;
import net.minecraft.class_8177;

public final class ModBlocks {

    private ModBlocks() {}

    public static final class_2248 CRUDE_STEEL_BLOCK = registerBlock("crude_steel_block",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10085)
            .method_31710(class_3620.field_15978)
            .method_9629(5.0f, 6.0f)
            .method_9626(class_2498.field_11533)
            .method_29292()));

    /** Storage block for steel ingots. */
    public static final class_2248 STEEL_BLOCK = registerBlock("steel_block",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_10085)
            .method_31710(class_3620.field_16005)
            .method_9629(6.0f, 8.0f)
            .method_9626(class_2498.field_11533)
            .method_29292()));

    /** Storage block for hot steel ingots — near-netherite toughness, beacon-compatible,
     *  glows like an active forge. */
    public static final class_2248 HOT_STEEL_BLOCK = registerBlock("hot_steel_block",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_22108)
            .method_31710(class_3620.field_16002)
            .method_9629(50.0f, 1200.0f)
            .method_9626(class_2498.field_22150)
            .method_9631(state -> 15)
            .method_29292()));

    /** Hot steel lantern — hangs like a vanilla lantern and glows (light 15). */
    public static final class_2248 HOT_STEEL_LANTERN = registerBlock("hot_steel_lantern",
        new HotSteelLanternBlock(class_4970.class_2251.method_9630(class_2246.field_16541)
            .method_31710(class_3620.field_16002)
            .method_9629(5.0f, 8.0f)
            .method_9631(state -> 15)
            .method_9626(class_2498.field_11533)
            .method_29292()));

    /** Hot steel stairs — decorative glowing stairs. */
    public static final class_2248 HOT_STEEL_STAIRS = registerBlock("hot_steel_stairs",
        new class_2510(HOT_STEEL_BLOCK.method_9564(),
            class_4970.class_2251.method_9630(HOT_STEEL_BLOCK)
                .method_9631(state -> 10)));

    /** Hot steel slab — decorative glowing slab. */
    public static final class_2248 HOT_STEEL_SLAB = registerBlock("hot_steel_slab",
        new class_2482(class_4970.class_2251.method_9630(HOT_STEEL_BLOCK)
            .method_9631(state -> 10)));

    /** Hot steel wall — decorative glowing wall. */
    public static final class_2248 HOT_STEEL_WALL = registerBlock("hot_steel_wall",
        new class_2544(class_4970.class_2251.method_9630(HOT_STEEL_BLOCK)
            .method_9631(state -> 10)));

    /** Hot steel forge — repairs Hot Steel gear using ingots. */
    public static final class_2248 HOT_STEEL_FORGE = registerBlock("hot_steel_forge",
        new HotSteelForgeBlock(class_4970.class_2251.method_9630(class_2246.field_10085)
            .method_31710(class_3620.field_16002)
            .method_9629(8.0f, 12.0f)
            .method_9631(state -> 15)
            .method_9626(class_2498.field_11533)
            .method_29292()));

    /** Hot steel smelter — auto-smelts any ore dropped on top of it. */
    public static final class_2248 HOT_STEEL_SMELTER = registerBlock("hot_steel_smelter",
        new HotSteelSmelterBlock(class_4970.class_2251.method_9630(class_2246.field_10085)
            .method_31710(class_3620.field_16002)
            .method_9629(8.0f, 12.0f)
            .method_9631(state -> 15)
            .method_9626(class_2498.field_11533)
            .method_29292()));

    /** Hot steel door — fireproof metal door. */
    public static final class_2248 HOT_STEEL_DOOR = registerBlock("hot_steel_door",
        new class_2323(class_8177.field_42819,
            class_4970.class_2251.method_9630(class_2246.field_9973)
                .method_31710(class_3620.field_16002)
                .method_9629(6.0f, 10.0f)
                .method_9626(class_2498.field_11533)
                .method_29292()));

    /** Hot steel trapdoor — fireproof metal trapdoor. */
    public static final class_2248 HOT_STEEL_TRAPDOOR = registerBlock("hot_steel_trapdoor",
        new class_2533(class_8177.field_42819,
            class_4970.class_2251.method_9630(class_2246.field_10453)
                .method_31710(class_3620.field_16002)
                .method_9629(6.0f, 10.0f)
                .method_9626(class_2498.field_11533)
                .method_29292()));

    /** Hot steel fence — decorative metal fence. */
    public static final class_2248 HOT_STEEL_FENCE = registerBlock("hot_steel_fence",
        new class_2354(class_4970.class_2251.method_9630(class_2246.field_10576)
            .method_31710(class_3620.field_16002)
            .method_9629(6.0f, 10.0f)
            .method_9626(class_2498.field_11533)
            .method_29292()));

    /** Hot steel bricks — chunky decorative building block. */
    public static final class_2248 HOT_STEEL_BRICKS = registerBlock("hot_steel_bricks",
        new class_2248(class_4970.class_2251.method_9630(class_2246.field_22108)
            .method_31710(class_3620.field_16002)
            .method_9629(12.0f, 200.0f)
            .method_9626(class_2498.field_22150)
            .method_9631(state -> 10)
            .method_29292()));

    /** Hot steel pressure plate — ignites whatever stands on it. */
    public static final class_2248 HOT_STEEL_PRESSURE_PLATE = registerBlock("hot_steel_pressure_plate",
        new HotSteelPressurePlateBlock(class_8177.field_42819,
            class_4970.class_2251.method_9630(class_2246.field_10158)
                .method_31710(class_3620.field_16002)
                .method_9629(3.0f, 10.0f)
                .method_9626(class_2498.field_11533)
                .method_29292()));

    /** Hot steel chain — glowing, fireproof chain for decoration. */
    public static final class_2248 HOT_STEEL_CHAIN = registerBlock("hot_steel_chain",
        new class_5172(class_4970.class_2251.method_9630(class_2246.field_23985)
            .method_31710(class_3620.field_16002)
            .method_9629(5.0f, 8.0f)
            .method_9631(state -> 7)
            .method_9626(class_2498.field_24119)
            .method_29292()));

    /** Hot steel ladder — glowing metal ladder that never burns. */
    public static final class_2248 HOT_STEEL_LADDER = registerBlock("hot_steel_ladder",
        new class_2399(class_4970.class_2251.method_9630(class_2246.field_9983)
            .method_31710(class_3620.field_16002)
            .method_9629(0.8f, 8.0f)
            .method_9631(state -> 5)
            .method_9626(class_2498.field_11533)));

    private static class_2248 registerBlock(String name, class_2248 block) {
        class_2960 id = HotSteel.id(name);
        class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new class_1792.class_1793()));
        return class_2378.method_10230(class_7923.field_41175, id, block);
    }

    public static void register() {
        HotSteel.LOGGER.info("Registering Hot Steel blocks");
    }
}
