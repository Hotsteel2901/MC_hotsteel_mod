package com.hotsteel.registry;

import com.hotsteel.HotSteel;
import com.hotsteel.entity.FireWraithEntity;
import com.hotsteel.entity.HotSteelArrowEntity;
import com.hotsteel.entity.HotSteelTridentEntity;
import com.hotsteel.entity.LavaBottleEntity;
import com.hotsteel.entity.LavaGolemEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public final class ModEntities {

    private ModEntities() {}

    public static final class_1299<HotSteelTridentEntity> HOT_STEEL_TRIDENT = register(
        "hot_steel_trident",
        class_1299.class_1300.<HotSteelTridentEntity>method_5903(HotSteelTridentEntity::new, class_1311.field_17715)
            .method_17687(0.5f, 0.5f)
            .method_27299(4)
            .method_27300(20)
            .method_5905("hot_steel_trident"));

    public static final class_1299<HotSteelArrowEntity> HOT_STEEL_ARROW = register(
        "hot_steel_arrow",
        class_1299.class_1300.<HotSteelArrowEntity>method_5903(HotSteelArrowEntity::new, class_1311.field_17715)
            .method_17687(0.5f, 0.5f)
            .method_27299(4)
            .method_27300(20)
            .method_5905("hot_steel_arrow"));

    /** Thrown bottle of lava. */
    public static final class_1299<LavaBottleEntity> LAVA_BOTTLE = register(
        "lava_bottle",
        class_1299.class_1300.<LavaBottleEntity>method_5903(LavaBottleEntity::new, class_1311.field_17715)
            .method_17687(0.25f, 0.25f)
            .method_27299(4)
            .method_27300(10)
            .method_5905("lava_bottle"));

    /** Molten guardian golem. */
    public static final class_1299<LavaGolemEntity> LAVA_GOLEM = register(
        "lava_golem",
        class_1299.class_1300.<LavaGolemEntity>method_5903(LavaGolemEntity::new, class_1311.field_6294)
            .method_17687(1.4f, 2.7f)
            .method_27299(10)
            .method_19947()
            .method_5905("lava_golem"));

    /** Blazing Nether wraith — stronger than a Blaze, drops Molten Cores. */
    public static final class_1299<FireWraithEntity> FIRE_WRAITH = register(
        "fire_wraith",
        class_1299.class_1300.<FireWraithEntity>method_5903(FireWraithEntity::new, class_1311.field_6302)
            .method_17687(0.6f, 1.8f)
            .method_27299(8)
            .method_19947()
            .method_5905("fire_wraith"));

    private static <T extends class_1297> class_1299<T> register(String name, class_1299<T> type) {
        return class_2378.method_10230(class_7923.field_41177, HotSteel.id(name), type);
    }

    public static void register() {
        HotSteel.LOGGER.info("Registering Hot Steel entities");
    }
}
