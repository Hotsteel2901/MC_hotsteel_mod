package com.hotsteel.registry;

import com.hotsteel.HotSteel;
import com.hotsteel.item.HotSteelArrowItem;
import com.hotsteel.item.HotSteelAxeItem;
import com.hotsteel.item.HotSteelBowItem;
import com.hotsteel.item.HotSteelCrossbowItem;
import com.hotsteel.item.HotSteelFishingRodItem;
import com.hotsteel.item.HotSteelFireballItem;
import com.hotsteel.item.HotSteelHoeItem;
import com.hotsteel.item.HotSteelAppleItem;
import com.hotsteel.item.HotSteelMaceItem;
import com.hotsteel.item.HotSteelPaxelItem;
import com.hotsteel.item.HotSteelShieldItem;
import com.hotsteel.item.HotSteelShovelItem;
import com.hotsteel.item.HotSteelSickleItem;
import com.hotsteel.item.HotSteelSwordItem;
import com.hotsteel.item.HotSteelTridentItem;
import com.hotsteel.item.KnifeItem;
import com.hotsteel.item.LavaBottleItem;
import com.hotsteel.item.MoltenCoreItem;
import net.minecraft.class_1738;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1826;
import net.minecraft.class_1829;
import net.minecraft.class_2315;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

public final class ModItems {

    private ModItems() {}

    // ---- Materials ----
    public static final class_1792 CRUDE_STEEL = register("crude_steel",
        new class_1792(new class_1792.class_1793()));

    public static final class_1792 STEEL_INGOT = register("steel_ingot",
        new class_1792(new class_1792.class_1793().method_24359()));

    public static final class_1792 HOT_STEEL_INGOT = register("hot_steel_ingot",
        new class_1792(new class_1792.class_1793().method_24359()));

    /** Compact form of a hot steel ingot (9 = 1 ingot). */
    public static final class_1792 HOT_STEEL_NUGGET = register("hot_steel_nugget",
        new class_1792(new class_1792.class_1793().method_24359()));

    /** Rare molten heart dropped by Fire Wraiths — right-click to instantly
     *  smelt everything in your inventory. */
    public static final class_1792 MOLTEN_CORE = register("molten_core",
        new MoltenCoreItem(new class_1792.class_1793().method_24359()));

    /** Paxel: pickaxe + axe + shovel merged into one auto-smelting tool. */
    public static final class_1792 HOT_STEEL_PAXEL = register("hot_steel_paxel",
        new HotSteelPaxelItem(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1810.method_57346(ModMaterials.HotSteelTier.INSTANCE, 3.0f, -2.8f))));

    /** Hot Steel Apple: molten food that grants fire immunity + regeneration. */
    public static final class_1792 HOT_STEEL_APPLE = register("hot_steel_apple",
        new HotSteelAppleItem(new class_1792.class_1793().method_24359()
            .method_19265(new net.minecraft.class_4174.class_4175()
                .method_19238(8)
                .method_19237(1.2f)
                .method_19240()
                .method_19242())));

    /** Fishing rod that auto-cooks any fish it catches. */
    public static final class_1792 HOT_STEEL_FISHING_ROD = register("hot_steel_fishing_rod",
        new HotSteelFishingRodItem(new class_1792.class_1793().method_7895(600)));

    /** Sickle: harvests a 5x5 area of mature crops and replants them. */
    public static final class_1792 HOT_STEEL_SICKLE = register("hot_steel_sickle",
        new HotSteelSickleItem(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1829.method_57394(ModMaterials.HotSteelTier.INSTANCE, 2, -2.6f))));

    // ---- Armor ----
    public static final class_1792 HOT_STEEL_HELMET = register("hot_steel_helmet",
        new class_1738(ModMaterials.HOT_STEEL_ARMOR, class_1738.class_8051.field_41934,
            new class_1792.class_1793().method_24359()
                .method_7895(class_1738.class_8051.field_41934.method_56690(ModMaterials.ARMOR_DURABILITY_MULT))));

    public static final class_1792 HOT_STEEL_CHESTPLATE = register("hot_steel_chestplate",
        new class_1738(ModMaterials.HOT_STEEL_ARMOR, class_1738.class_8051.field_41935,
            new class_1792.class_1793().method_24359()
                .method_7895(class_1738.class_8051.field_41935.method_56690(ModMaterials.ARMOR_DURABILITY_MULT))));

    public static final class_1792 HOT_STEEL_LEGGINGS = register("hot_steel_leggings",
        new class_1738(ModMaterials.HOT_STEEL_ARMOR, class_1738.class_8051.field_41936,
            new class_1792.class_1793().method_24359()
                .method_7895(class_1738.class_8051.field_41936.method_56690(ModMaterials.ARMOR_DURABILITY_MULT))));

    public static final class_1792 HOT_STEEL_BOOTS = register("hot_steel_boots",
        new class_1738(ModMaterials.HOT_STEEL_ARMOR, class_1738.class_8051.field_41937,
            new class_1792.class_1793().method_24359()
                .method_7895(class_1738.class_8051.field_41937.method_56690(ModMaterials.ARMOR_DURABILITY_MULT))));

    // ---- Tools ----
    public static final class_1792 HOT_STEEL_SWORD = register("hot_steel_sword",
        new HotSteelSwordItem(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1829.method_57394(ModMaterials.HotSteelTier.INSTANCE, 4, -2.4f))));

    public static final class_1792 HOT_STEEL_PICKAXE = register("hot_steel_pickaxe",
        new class_1810(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1810.method_57346(ModMaterials.HotSteelTier.INSTANCE, 1.0f, -2.8f))));

    public static final class_1792 HOT_STEEL_AXE = register("hot_steel_axe",
        new HotSteelAxeItem(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1743.method_57346(ModMaterials.HotSteelTier.INSTANCE, 6.0f, -3.0f))));

    public static final class_1792 HOT_STEEL_SHOVEL = register("hot_steel_shovel",
        new HotSteelShovelItem(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1821.method_57346(ModMaterials.HotSteelTier.INSTANCE, 1.5f, -3.0f))));

    public static final class_1792 HOT_STEEL_HOE = register("hot_steel_hoe",
        new HotSteelHoeItem(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1794.method_57346(ModMaterials.HotSteelTier.INSTANCE, -4.0f, 0.0f))));

    // ---- New weapon: knife (light & fast) ----
    public static final class_1792 HOT_STEEL_KNIFE = register("hot_steel_knife",
        new KnifeItem(ModMaterials.HotSteelTier.INSTANCE, new class_1792.class_1793().method_24359()
            .method_57348(class_1829.method_57394(ModMaterials.HotSteelTier.INSTANCE, 1, -2.0f))));

    // ---- New weapon: mace (heavy smash) ----
    public static final class_1792 HOT_STEEL_MACE = register("hot_steel_mace",
        new HotSteelMaceItem(new class_1792.class_1793().method_24359()
            .method_57348(HotSteelMaceItem.method_59532())));

    // ---- Ranged / special ----
    public static final class_1792 HOT_STEEL_BOW = register("hot_steel_bow",
        new HotSteelBowItem(new class_1792.class_1793().method_24359().method_7895(1000)));

    public static final class_1792 HOT_STEEL_CROSSBOW = register("hot_steel_crossbow",
        new HotSteelCrossbowItem(new class_1792.class_1793().method_24359().method_7895(1200)));

    public static final class_1792 HOT_STEEL_TRIDENT = register("hot_steel_trident",
        new HotSteelTridentItem(new class_1792.class_1793().method_24359().method_7895(500)
            .method_57348(HotSteelTridentItem.createAttributes())));

    public static final class_1792 HOT_STEEL_SHIELD = register("hot_steel_shield",
        new HotSteelShieldItem(new class_1792.class_1793().method_24359().method_7895(500)));

    // ---- New ammunition: igniting arrows ----
    public static final class_1792 HOT_STEEL_ARROW = register("hot_steel_arrow",
        new HotSteelArrowItem(new class_1792.class_1793().method_24359()));

    // ---- New throwable: fireball ----
    public static final class_1792 HOT_STEEL_FIREBALL = register("hot_steel_fireball",
        new HotSteelFireballItem(new class_1792.class_1793().method_24359()));

    // ---- New throwable: lava bottle ----
    public static final class_1792 LAVA_BOTTLE = register("lava_bottle",
        new LavaBottleItem(new class_1792.class_1793()));

    // ---- Spawn egg: lava golem ----
    public static final class_1792 LAVA_GOLEM_SPAWN_EGG = register("lava_golem_spawn_egg",
        new class_1826(ModEntities.LAVA_GOLEM, 0x3d1707, 0xe0611f, new class_1792.class_1793()));

    // ---- Spawn egg: fire wraith ----
    public static final class_1792 FIRE_WRAITH_SPAWN_EGG = register("fire_wraith_spawn_egg",
        new class_1826(ModEntities.FIRE_WRAITH, 0xff5500, 0x2a0505, new class_1792.class_1793()));

    private static class_1792 register(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, HotSteel.id(name), item);
    }

    public static void register() {
        // Let dispensers actually shoot the Hot Steel arrow instead of dropping it.
        class_2315.method_58681(HOT_STEEL_ARROW);
        HotSteel.LOGGER.info("Registering Hot Steel items");
    }
}
