package com.hotsteel.registry;

import com.hotsteel.HotSteel;

import net.fabricmc.fabric.api.registry.FabricBrewingRecipeRegistryBuilder;
import net.minecraft.class_1293;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1847;
import net.minecraft.class_2378;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

/** Potions added by the mod (brewing recipes are registered in {@link #register()}). */
public final class ModPotions {

    private ModPotions() {}

    /** 60s of Super Fire Resistance — fire/lava immunity without any armor. */
    public static final class_6880<class_1842> SUPER_FIRE_RESISTANCE = class_2378.method_47985(
        class_7923.field_41179,
        HotSteel.id("super_fire_resistance"),
        new class_1842(new class_1293(ModEffects.SUPER_FIRE_RESISTANCE, 1200, 0)));

    /** Extended: 4 minutes of Super Fire Resistance. */
    public static final class_6880<class_1842> SUPER_FIRE_RESISTANCE_LONG = class_2378.method_47985(
        class_7923.field_41179,
        HotSteel.id("super_fire_resistance_long"),
        new class_1842(new class_1293(ModEffects.SUPER_FIRE_RESISTANCE, 4800, 0)));

    /** Strong: level II — even faster lava movement (30s). */
    public static final class_6880<class_1842> SUPER_FIRE_RESISTANCE_STRONG = class_2378.method_47985(
        class_7923.field_41179,
        HotSteel.id("super_fire_resistance_strong"),
        new class_1842(new class_1293(ModEffects.SUPER_FIRE_RESISTANCE, 600, 1)));

    public static void register() {
        FabricBrewingRecipeRegistryBuilder.BUILD.register(builder -> {
            // Awkward potion + hot steel ingot -> Potion of Super Fire Resistance
            builder.method_59705(class_1847.field_8999, ModItems.HOT_STEEL_INGOT, SUPER_FIRE_RESISTANCE);
            // Redstone -> extended, glowstone -> strong
            builder.method_59705(SUPER_FIRE_RESISTANCE, class_1802.field_8725, SUPER_FIRE_RESISTANCE_LONG);
            builder.method_59705(SUPER_FIRE_RESISTANCE, class_1802.field_8601, SUPER_FIRE_RESISTANCE_STRONG);
        });
        HotSteel.LOGGER.info("Registering Hot Steel potions");
    }
}
