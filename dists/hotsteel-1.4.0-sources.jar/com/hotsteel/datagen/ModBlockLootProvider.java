package com.hotsteel.datagen;

import java.util.concurrent.CompletableFuture;

import com.hotsteel.registry.ModBlocks;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;

public class ModBlockLootProvider extends FabricBlockLootTableProvider {

    public ModBlockLootProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries) {
        super(output, registries);
    }

    @Override
    public void method_10379() {
        this.method_46025(ModBlocks.CRUDE_STEEL_BLOCK);
        this.method_46025(ModBlocks.STEEL_BLOCK);
        this.method_46025(ModBlocks.HOT_STEEL_BLOCK);
        this.method_46025(ModBlocks.HOT_STEEL_STAIRS);
        this.method_46025(ModBlocks.HOT_STEEL_SLAB);
        this.method_46025(ModBlocks.HOT_STEEL_WALL);
        this.method_46025(ModBlocks.HOT_STEEL_FORGE);
        this.method_46025(ModBlocks.HOT_STEEL_SMELTER);
        this.method_46025(ModBlocks.HOT_STEEL_DOOR);
        this.method_46025(ModBlocks.HOT_STEEL_TRAPDOOR);
        this.method_46025(ModBlocks.HOT_STEEL_FENCE);
        this.method_46025(ModBlocks.HOT_STEEL_BRICKS);
        this.method_46025(ModBlocks.HOT_STEEL_PRESSURE_PLATE);
        this.method_46025(ModBlocks.HOT_STEEL_LANTERN);
        this.method_46025(ModBlocks.HOT_STEEL_CHAIN);
        this.method_46025(ModBlocks.HOT_STEEL_LADDER);
    }
}
