package com.hotsteel.datagen;

import com.hotsteel.registry.ModBlocks;
import com.hotsteel.registry.ModItems;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;

public class ModModelProvider extends FabricModelProvider {

    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 gen) {
        gen.method_25641(ModBlocks.CRUDE_STEEL_BLOCK);
        gen.method_25641(ModBlocks.STEEL_BLOCK);
        gen.method_25641(ModBlocks.HOT_STEEL_BLOCK);
        gen.method_25641(ModBlocks.HOT_STEEL_BRICKS);
        gen.method_25641(ModBlocks.HOT_STEEL_SMELTER);
        // forge/lantern/door/trapdoor/fence/pressure-plate models are hand-written
    }

    @Override
    public void generateItemModels(class_4915 gen) {
        gen.method_25733(ModItems.CRUDE_STEEL, class_4943.field_22938);
        gen.method_25733(ModItems.STEEL_INGOT, class_4943.field_22938);
        gen.method_25733(ModItems.HOT_STEEL_INGOT, class_4943.field_22938);
        gen.method_25733(ModItems.HOT_STEEL_NUGGET, class_4943.field_22938);
        gen.method_25733(ModItems.MOLTEN_CORE, class_4943.field_22938);
        gen.method_25733(ModItems.HOT_STEEL_APPLE, class_4943.field_22938);

        gen.method_25733(ModItems.HOT_STEEL_HELMET, class_4943.field_22938);
        gen.method_25733(ModItems.HOT_STEEL_CHESTPLATE, class_4943.field_22938);
        gen.method_25733(ModItems.HOT_STEEL_LEGGINGS, class_4943.field_22938);
        gen.method_25733(ModItems.HOT_STEEL_BOOTS, class_4943.field_22938);

        gen.method_25733(ModItems.HOT_STEEL_SWORD, class_4943.field_22939);
        gen.method_25733(ModItems.HOT_STEEL_MACE, class_4943.field_22939);
        gen.method_25733(ModItems.HOT_STEEL_KNIFE, class_4943.field_22939);
        gen.method_25733(ModItems.HOT_STEEL_SICKLE, class_4943.field_22939);
        gen.method_25733(ModItems.HOT_STEEL_PICKAXE, class_4943.field_22939);
        gen.method_25733(ModItems.HOT_STEEL_AXE, class_4943.field_22939);
        gen.method_25733(ModItems.HOT_STEEL_SHOVEL, class_4943.field_22939);
        gen.method_25733(ModItems.HOT_STEEL_HOE, class_4943.field_22939);
        gen.method_25733(ModItems.HOT_STEEL_PAXEL, class_4943.field_22939);
        gen.method_25733(ModItems.HOT_STEEL_ARROW, class_4943.field_22938);
        gen.method_25733(ModItems.HOT_STEEL_FIREBALL, class_4943.field_22938);

        // bow / crossbow / trident / shield / fishing-rod item models are hand-written
    }
}
