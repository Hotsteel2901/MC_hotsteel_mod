package com.hotsteel.datagen;

import java.util.concurrent.CompletableFuture;

import com.hotsteel.registry.ModBlocks;
import com.hotsteel.registry.ModItems;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;

public class ModRecipeProvider extends FabricRecipeProvider {

    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registries) {
        super(output, registries);
    }

    @Override
    public void method_10419(class_8790 exporter) {
        // iron ingot -> crude steel (blast furnace)
        class_2454.method_10473(class_1856.method_8091(class_1802.field_8620),
                class_7800.field_40642, ModItems.CRUDE_STEEL, 0.7f, 100)
            .method_10469("has_iron_ingot", method_10426(class_1802.field_8620))
            .method_36443(exporter, "crude_steel_from_blasting");

        // 4 crude steel -> crude steel block
        class_2447.method_10437(class_7800.field_40634, ModBlocks.CRUDE_STEEL_BLOCK)
            .method_10439("SS")
            .method_10439("SS")
            .method_10434('S', ModItems.CRUDE_STEEL)
            .method_10429("has_crude_steel", method_10426(ModItems.CRUDE_STEEL))
            .method_10431(exporter);

        // crude steel block -> steel ingot (blast furnace)
        class_2454.method_10473(class_1856.method_8091(ModBlocks.CRUDE_STEEL_BLOCK),
                class_7800.field_40642, ModItems.STEEL_INGOT, 1.0f, 100)
            .method_10469("has_crude_steel_block", method_10426(ModBlocks.CRUDE_STEEL_BLOCK))
            .method_36443(exporter, "steel_ingot_from_blasting");

        // ---- Storage blocks ----
        // 9 steel ingot <-> steel block
        class_2447.method_10437(class_7800.field_40634, ModBlocks.STEEL_BLOCK)
            .method_10439("SSS").method_10439("SSS").method_10439("SSS")
            .method_10434('S', ModItems.STEEL_INGOT)
            .method_10429("has_steel_ingot", method_10426(ModItems.STEEL_INGOT)).method_10431(exporter);
        class_2450.method_10448(class_7800.field_40642, ModItems.STEEL_INGOT, 9)
            .method_10454(ModBlocks.STEEL_BLOCK)
            .method_10442("has_steel_block", method_10426(ModBlocks.STEEL_BLOCK)).method_10431(exporter);

        // 9 hot steel ingot <-> hot steel block
        class_2447.method_10437(class_7800.field_40634, ModBlocks.HOT_STEEL_BLOCK)
            .method_10439("III").method_10439("III").method_10439("III")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2450.method_10448(class_7800.field_40642, ModItems.HOT_STEEL_INGOT, 9)
            .method_10454(ModBlocks.HOT_STEEL_BLOCK)
            .method_10442("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);

        // ---- Equipment from hot steel ingot ----
        // Armor
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_HELMET)
            .method_10439("III").method_10439("I I")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_CHESTPLATE)
            .method_10439("I I").method_10439("III").method_10439("III")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_LEGGINGS)
            .method_10439("III").method_10439("I I").method_10439("I I")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_BOOTS)
            .method_10439("I I").method_10439("I I")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // Tools & weapons
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_SWORD)
            .method_10439("I").method_10439("I").method_10439("S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_KNIFE)
            .method_10439("I").method_10439("S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_MACE)
            .method_10439(" I ").method_10439("III").method_10439(" I ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_PICKAXE)
            .method_10439("III").method_10439(" S ").method_10439(" S ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_AXE)
            .method_10439("II").method_10439("IS").method_10439(" S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_SHOVEL)
            .method_10439("I").method_10439("S").method_10439("S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_HOE)
            .method_10439("II").method_10439(" S").method_10439(" S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // Ranged / special
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_BOW)
            .method_10439(" IR").method_10439("I R").method_10439(" IR")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('R', class_1802.field_8276)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_CROSSBOW)
            .method_10439("ITI").method_10439("RSR").method_10439(" I ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8366)
            .method_10434('T', class_1802.field_8600).method_10434('R', class_1802.field_8276)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_TRIDENT)
            .method_10439("III").method_10439(" I ").method_10439(" I ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40639, ModItems.HOT_STEEL_SHIELD)
            .method_10439("I I").method_10439("III").method_10439(" I ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // 4 arrows + 1 hot steel ingot -> 4 hot steel arrows
        class_2450.method_10448(class_7800.field_40639, ModItems.HOT_STEEL_ARROW, 4)
            .method_10449(class_1802.field_8107, 4)
            .method_10454(ModItems.HOT_STEEL_INGOT)
            .method_10442("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // ---- Hot steel decorative blocks ----
        // 6 hot steel blocks -> 4 stairs
        class_2447.method_10436(class_7800.field_40634, ModBlocks.HOT_STEEL_STAIRS, 4)
            .method_10439("B  ").method_10439("BB ").method_10439("BBB")
            .method_10434('B', ModBlocks.HOT_STEEL_BLOCK)
            .method_10429("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);
        // 3 hot steel blocks -> 6 slabs
        class_2447.method_10436(class_7800.field_40634, ModBlocks.HOT_STEEL_SLAB, 6)
            .method_10439("BBB")
            .method_10434('B', ModBlocks.HOT_STEEL_BLOCK)
            .method_10429("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);
        // 6 hot steel blocks -> 6 walls
        class_2447.method_10436(class_7800.field_40634, ModBlocks.HOT_STEEL_WALL, 6)
            .method_10439("BBB").method_10439("BBB")
            .method_10434('B', ModBlocks.HOT_STEEL_BLOCK)
            .method_10429("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);

        // ---- Hot steel forge ----
        class_2447.method_10437(class_7800.field_40634, ModBlocks.HOT_STEEL_FORGE)
            .method_10439("III").method_10439("ILI").method_10439("III")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('L', class_1802.field_8187)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // ---- Lava bottle ----
        class_2450.method_10448(class_7800.field_40642, ModItems.LAVA_BOTTLE, 3)
            .method_10454(class_1802.field_8469)
            .method_10454(class_1802.field_8187)
            .method_10442("has_lava_bucket", method_10426(class_1802.field_8187)).method_10431(exporter);

        // ---- Hot steel nuggets <-> ingot ----
        class_2447.method_10437(class_7800.field_40642, ModItems.HOT_STEEL_INGOT)
            .method_10439("NNN").method_10439("NNN").method_10439("NNN")
            .method_10434('N', ModItems.HOT_STEEL_NUGGET)
            .method_10429("has_hot_steel_nugget", method_10426(ModItems.HOT_STEEL_NUGGET))
            .method_36443(exporter, "hot_steel_ingot_from_nugget");
        class_2450.method_10448(class_7800.field_40642, ModItems.HOT_STEEL_NUGGET, 9)
            .method_10454(ModItems.HOT_STEEL_INGOT)
            .method_10442("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // ---- Hot steel fishing rod ----
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_FISHING_ROD)
            .method_10439("  I").method_10439(" IS").method_10439("I S")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8276)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // ---- Hot steel sickle ----
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_SICKLE)
            .method_10439(" II").method_10439("I  ").method_10439(" S ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // ---- Hot steel bricks ----
        class_2447.method_10436(class_7800.field_40634, ModBlocks.HOT_STEEL_BRICKS, 4)
            .method_10439("BB").method_10439("BB")
            .method_10434('B', ModBlocks.HOT_STEEL_BLOCK)
            .method_10429("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);

        // ---- Hot steel door / trapdoor / fence ----
        class_2447.method_10436(class_7800.field_40634, ModBlocks.HOT_STEEL_DOOR, 3)
            .method_10439("BB").method_10439("BB").method_10439("BB")
            .method_10434('B', ModBlocks.HOT_STEEL_BLOCK)
            .method_10429("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);
        class_2447.method_10436(class_7800.field_40634, ModBlocks.HOT_STEEL_TRAPDOOR, 2)
            .method_10439("BB").method_10439("BB")
            .method_10434('B', ModBlocks.HOT_STEEL_BLOCK)
            .method_10429("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);
        class_2447.method_10436(class_7800.field_40634, ModBlocks.HOT_STEEL_FENCE, 3)
            .method_10439("B B").method_10439("B B")
            .method_10434('B', ModBlocks.HOT_STEEL_BLOCK)
            .method_10429("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);
        class_2447.method_10437(class_7800.field_40636, ModBlocks.HOT_STEEL_PRESSURE_PLATE)
            .method_10439("BB")
            .method_10434('B', ModBlocks.HOT_STEEL_BLOCK)
            .method_10429("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);

        // ---- Hot steel smelter ----
        class_2447.method_10437(class_7800.field_40634, ModBlocks.HOT_STEEL_SMELTER)
            .method_10439("HHH").method_10439("HIH").method_10439("HHH")
            .method_10434('H', ModBlocks.HOT_STEEL_BLOCK).method_10434('I', class_1802.field_8620)
            .method_10429("has_hot_steel_block", method_10426(ModBlocks.HOT_STEEL_BLOCK)).method_10431(exporter);

        // ---- Molten core can be smelted back into 2 hot steel ingots ----
        class_2450.method_10448(class_7800.field_40642, ModItems.HOT_STEEL_INGOT, 2)
            .method_10454(ModItems.MOLTEN_CORE)
            .method_10442("has_molten_core", method_10426(ModItems.MOLTEN_CORE)).method_36443(exporter, "molten_core_to_ingots");

        // ---- Hot steel paxel (pickaxe + axe + shovel) ----
        class_2447.method_10437(class_7800.field_40638, ModItems.HOT_STEEL_PAXEL)
            .method_10439("IPI").method_10439("SAS").method_10439(" S ")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10434('P', ModItems.HOT_STEEL_PICKAXE)
            .method_10434('A', ModItems.HOT_STEEL_AXE)
            .method_10434('S', class_1802.field_8600)
            .method_10429("has_hot_steel_pickaxe", method_10426(ModItems.HOT_STEEL_PICKAXE)).method_10431(exporter);

        // ---- Hot steel apple ----
        class_2447.method_10437(class_7800.field_40640, ModItems.HOT_STEEL_APPLE)
            .method_10439("III").method_10439("IAI").method_10439("III")
            .method_10434('I', ModItems.HOT_STEEL_INGOT).method_10434('A', class_1802.field_8279)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);

        // ---- Hot steel chain ----
        class_2447.method_10436(class_7800.field_40634, ModBlocks.HOT_STEEL_CHAIN, 6)
            .method_10439("N N").method_10439("N N").method_10439("N N")
            .method_10434('N', ModItems.HOT_STEEL_NUGGET)
            .method_10429("has_hot_steel_nugget", method_10426(ModItems.HOT_STEEL_NUGGET)).method_10431(exporter);

        // ---- Hot steel ladder ----
        class_2447.method_10436(class_7800.field_40634, ModBlocks.HOT_STEEL_LADDER, 4)
            .method_10439("I I").method_10439("III").method_10439("I I")
            .method_10434('I', ModItems.HOT_STEEL_INGOT)
            .method_10429("has_hot_steel_ingot", method_10426(ModItems.HOT_STEEL_INGOT)).method_10431(exporter);
    }
}
