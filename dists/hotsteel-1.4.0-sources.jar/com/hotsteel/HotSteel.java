package com.hotsteel;

import com.hotsteel.entity.LavaGolemEntity;
import com.hotsteel.logic.SuperFireResistanceHandler;
import com.hotsteel.registry.ModBlocks;
import com.hotsteel.registry.ModBlockEntities;
import com.hotsteel.registry.ModCreativeTab;
import com.hotsteel.registry.ModEffects;
import com.hotsteel.registry.ModEntities;
import com.hotsteel.registry.ModItems;
import com.hotsteel.registry.ModMaterials;
import com.hotsteel.registry.ModPotions;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HotSteel implements ModInitializer {
    public static final String MOD_ID = "hotsteel";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModMaterials.init();
        ModBlocks.register();
        ModBlockEntities.register();
        ModEntities.register();
        ModEffects.register();
        ModItems.register();
        ModPotions.register();
        ModCreativeTab.register();
        FabricDefaultAttributeRegistry.register(ModEntities.LAVA_GOLEM, LavaGolemEntity.method_26886());
        FabricDefaultAttributeRegistry.register(ModEntities.FIRE_WRAITH,
            net.minecraft.class_1545.method_26906());
        // Fire Wraiths haunt the Nether like Blazes.
        net.fabricmc.fabric.api.biome.v1.BiomeModifications.addSpawn(
            net.fabricmc.fabric.api.biome.v1.BiomeSelectors.tag(
                net.minecraft.class_6908.field_36518),
            net.minecraft.class_1311.field_6302,
            ModEntities.FIRE_WRAITH, 12, 1, 3);
        SuperFireResistanceHandler.register();
        LOGGER.info("Hot Steel initialized");
    }
}
