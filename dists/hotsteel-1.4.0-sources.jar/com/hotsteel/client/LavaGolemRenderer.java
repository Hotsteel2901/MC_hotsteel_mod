package com.hotsteel.client;

import com.hotsteel.HotSteel;
import com.hotsteel.entity.LavaGolemEntity;
import net.minecraft.class_2960;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_574;
import net.minecraft.class_927;

/** Renders the Lava Golem with the iron-golem model but a molten-hot texture. */
public class LavaGolemRenderer extends class_927<LavaGolemEntity, class_574<LavaGolemEntity>> {

    public static final class_2960 TEXTURE = HotSteel.id("textures/entity/lava_golem.png");

    public LavaGolemRenderer(class_5617.class_5618 context) {
        super(context, new class_574<>(context.method_32167(class_5602.field_27608)), 0.7f);
    }

    @Override
    public class_2960 getTextureLocation(LavaGolemEntity entity) {
        return TEXTURE;
    }
}
