package com.hotsteel.client;

import com.hotsteel.HotSteel;
import com.hotsteel.entity.FireWraithEntity;
import net.minecraft.class_2960;
import net.minecraft.class_555;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_927;

/** Renders the Fire Wraith with the Blaze model but a molten wraith texture. */
public class FireWraithRenderer extends class_927<FireWraithEntity, class_555<FireWraithEntity>> {

    public static final class_2960 TEXTURE = HotSteel.id("textures/entity/fire_wraith.png");

    public FireWraithRenderer(class_5617.class_5618 context) {
        super(context, new class_555<>(context.method_32167(class_5602.field_27684)), 0.5f);
    }

    @Override
    public class_2960 getTextureLocation(FireWraithEntity entity) {
        return TEXTURE;
    }

    @Override
    protected int getBlockLightLevel(FireWraithEntity entity, net.minecraft.class_2338 pos) {
        return 15;
    }
}
