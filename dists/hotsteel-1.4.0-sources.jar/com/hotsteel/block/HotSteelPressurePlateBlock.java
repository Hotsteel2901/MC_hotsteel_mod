package com.hotsteel.block;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2440;
import net.minecraft.class_2680;
import net.minecraft.class_8177;

/**
 * Hot Steel pressure plate: a redstone pressure plate that also sears whatever
 * stands on it, setting living entities on fire for 3 seconds.
 */
public class HotSteelPressurePlateBlock extends class_2440 {

    private static final int IGNITE_TICKS = 60;

    public HotSteelPressurePlateBlock(class_8177 type, class_2251 properties) {
        super(type, properties);
    }

    @Override
    public void method_9548(class_2680 state, class_1937 level, class_2338 pos, class_1297 entity) {
        super.method_9548(state, level, pos, entity);
        if (!level.field_9236 && entity instanceof class_1309 living
            && state.method_11654(field_11358)) {
            living.method_20803(Math.max(living.method_20802(), IGNITE_TICKS));
        }
    }
}
