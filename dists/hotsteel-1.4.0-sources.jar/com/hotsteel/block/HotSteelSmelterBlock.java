package com.hotsteel.block;

import com.hotsteel.registry.ModBlockEntities;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2398;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

/**
 * Hot Steel Smelter: a glowing plate that smelts any mineable/ore item dropped
 * on top of it (auto-smelt via the same map as the Hot Steel pickaxe). No GUI —
 * just place raw ores on it and collect the ingots.
 */
public class HotSteelSmelterBlock extends class_2248 implements class_2343 {

    public HotSteelSmelterBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new HotSteelSmelterBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 level, class_2680 state,
                                                                  class_2591<T> type) {
        return level.field_9236 ? null
            : createTickerHelper(type, ModBlockEntities.HOT_STEEL_SMELTER, HotSteelSmelterBlockEntity::serverTick);
    }

    @SuppressWarnings("unchecked")
    private static <E extends class_2586, A extends class_2586> class_5558<A> createTickerHelper(
            class_2591<A> type, class_2591<E> expected, class_5558<? super E> ticker) {
        return type == expected ? (class_5558<A>) ticker : null;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 level, class_2338 pos, class_5819 random) {
        if (random.method_43048(4) == 0) {
            level.method_8406(class_2398.field_27783,
                pos.method_10263() + 0.5 + (random.method_43058() - 0.5) * 0.6,
                pos.method_10264() + 1.05,
                pos.method_10260() + 0.5 + (random.method_43058() - 0.5) * 0.6,
                0.0, 0.05, 0.0);
        }
        if (random.method_43048(6) == 0) {
            level.method_8486(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                class_3417.field_14576, class_3419.field_15245, 0.4f, 1.3f, false);
        }
    }

    /** No stored inventory — the smelter converts dropped items in the world. */
    @Override
    public void method_9536(class_2680 state, class_1937 level, class_2338 pos, class_2680 newState, boolean isMoving) {
        if (state.method_31709() && !state.method_27852(newState.method_26204())) {
            level.method_8544(pos);
        }
        super.method_9536(state, level, pos, newState, isMoving);
    }
}
