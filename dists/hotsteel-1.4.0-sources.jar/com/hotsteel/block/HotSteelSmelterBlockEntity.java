package com.hotsteel.block;

import com.hotsteel.logic.AutoSmeltHelper;
import com.hotsteel.registry.ModBlockEntities;
import java.util.List;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for the Hot Steel Smelter: any ore/raw item that lands on the
 * block is instantly smelted (converted to its ingot form, same map as the Hot
 * Steel pickaxe) with a lava-flash effect.
 */
public class HotSteelSmelterBlockEntity extends class_2586 {

    public HotSteelSmelterBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    /** Constructor matching the {@code BlockEntityType.BlockEntitySupplier} signature. */
    public HotSteelSmelterBlockEntity(class_2338 pos, class_2680 state) {
        this(ModBlockEntities.HOT_STEEL_SMELTER, pos, state);
    }

    public static void serverTick(class_1937 level, class_2338 pos, class_2680 state,
                                  HotSteelSmelterBlockEntity be) {
        if (level.field_9236) {
            return;
        }
        class_3218 server = (class_3218) level;
        class_238 box = new class_238(pos).method_1012(0.0, 1.0, 0.0).method_1009(0.3, 0.1, 0.3);
        List<class_1542> items = server.method_18467(class_1542.class, box);
        if (items.isEmpty()) {
            return;
        }
        for (class_1542 itemEntity : items) {
            class_1799 stack = itemEntity.method_6983();
            class_1792 smelted = AutoSmeltHelper.SMELT_MAP.get(stack.method_7909());
            if (smelted == null) {
                continue;
            }
            itemEntity.method_6979(new class_1799(smelted, stack.method_7947()));
            server.method_14199(class_2398.field_11239,
                pos.method_10263() + 0.5, pos.method_10264() + 1.0, pos.method_10260() + 0.5,
                12, 0.3, 0.1, 0.3, 0.0);
            level.method_8396(null, pos, class_3417.field_19198, class_3419.field_15245, 0.8f, 1.2f);
            // Award the advancement to any nearby player.
            if (server.method_18459(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, 10.0, false)
                    instanceof net.minecraft.class_3222 player) {
                com.hotsteel.logic.AdvancementHelper.award(player, "smelter_use", "smelt_ore");
            }
        }
    }
}
