package com.hotsteel.block;

import net.minecraft.class_3749;
import net.minecraft.class_4970;

/** Hot Steel lantern — hangs like a vanilla lantern and glows brightly. */
public class HotSteelLanternBlock extends class_3749 {

    public HotSteelLanternBlock(class_4970.class_2251 properties) {
        super(properties);
    }
}
