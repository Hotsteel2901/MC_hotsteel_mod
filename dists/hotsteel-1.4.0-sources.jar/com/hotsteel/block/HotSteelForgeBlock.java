package com.hotsteel.block;

import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_9062;
import com.hotsteel.logic.AdvancementHelper;
import com.hotsteel.registry.ModItems;

/**
 * Hot Steel forge: a glowing decorative block that repairs damaged Hot Steel
 * equipment. Right-click the forge while holding a damaged Hot Steel tool/armor
 * to restore it to full durability in exchange for Hot Steel ingots
 * (1 ingot per 200 durability, minimum 1).
 */
public class HotSteelForgeBlock extends class_2248 {

    /** All Hot Steel equipment that can be repaired at the forge. */
    private static final Set<class_1792> REPAIRABLE = Set.of(
        ModItems.HOT_STEEL_HELMET, ModItems.HOT_STEEL_CHESTPLATE,
        ModItems.HOT_STEEL_LEGGINGS, ModItems.HOT_STEEL_BOOTS,
        ModItems.HOT_STEEL_SWORD, ModItems.HOT_STEEL_MACE, ModItems.HOT_STEEL_KNIFE,
        ModItems.HOT_STEEL_PICKAXE, ModItems.HOT_STEEL_AXE, ModItems.HOT_STEEL_SHOVEL,
        ModItems.HOT_STEEL_HOE, ModItems.HOT_STEEL_BOW, ModItems.HOT_STEEL_CROSSBOW,
        ModItems.HOT_STEEL_TRIDENT, ModItems.HOT_STEEL_SHIELD);

    /** Hot Steel ingots consumed per 200 durability restored. */
    private static final int DURABILITY_PER_INGOT = 200;

    public HotSteelForgeBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected class_9062 method_55765(class_1799 stack, class_2680 state, class_1937 level,
                                              class_2338 pos, class_1657 player, class_1268 hand,
                                              class_3965 hitResult) {
        if (!REPAIRABLE.contains(stack.method_7909()) || stack.method_7936() <= 0) {
            return class_9062.field_47731;
        }
        int damage = stack.method_7919();
        if (damage <= 0) {
            if (!level.field_9236) {
                player.method_7353(
                    class_2561.method_43471("message.hotsteel.forge_no_damage"), true);
            }
            return class_9062.field_47728;
        }

        int ingotsNeeded = Math.max(1, (damage + DURABILITY_PER_INGOT - 1) / DURABILITY_PER_INGOT);
        int available = countIngots(player);
        if (available < ingotsNeeded) {
            if (!level.field_9236) {
                player.method_7353(
                    class_2561.method_43469("message.hotsteel.forge_need_ingots", ingotsNeeded), true);
            }
            return class_9062.field_47728;
        }

        if (!level.field_9236) {
            if (!player.method_31549().field_7477) {
                removeIngots(player, ingotsNeeded);
            }
            stack.method_7974(0);
            level.method_8396(null, pos, class_3417.field_14559, class_3419.field_15245, 1.0f, 1.2f);
            if (level instanceof class_3218 serverLevel) {
                serverLevel.method_14199(class_2398.field_11239,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.9, pos.method_10260() + 0.5, 20, 0.3, 0.1, 0.3, 0.0);
            }
            player.method_7353(
                class_2561.method_43469("message.hotsteel.forge_repair", ingotsNeeded), true);
            if (player instanceof class_3222 serverPlayer) {
                AdvancementHelper.award(serverPlayer, "forge_repair", "repair_gear");
            }
        }
        return class_9062.field_47728;
    }

    private static int countIngots(class_1657 player) {
        int count = 0;
        for (class_1799 stack : player.method_31548().field_7547) {
            if (stack.method_31574(ModItems.HOT_STEEL_INGOT)) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private static void removeIngots(class_1657 player, int amount) {
        for (class_1799 stack : player.method_31548().field_7547) {
            if (amount <= 0) {
                break;
            }
            if (stack.method_31574(ModItems.HOT_STEEL_INGOT)) {
                int removed = Math.min(stack.method_7947(), amount);
                stack.method_7934(removed);
                amount -= removed;
            }
        }
    }
}
