package com.hotsteel.item;

import com.hotsteel.logic.AdvancementHelper;
import com.hotsteel.registry.ModEffects;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3956;
import net.minecraft.class_9696;

/**
 * Molten Core: the blazing heart of a Fire Wraith. Right-click to consume it
 * and instantly smelt every smeltable item in your inventory (using the real
 * furnace recipe map — no furnace needed), while gaining a short burst of
 * Super Fire Resistance.
 */
public class MoltenCoreItem extends class_1792 {

    public MoltenCoreItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (player.method_7357().method_7904(this)) {
            return class_1271.method_22431(stack);
        }
        if (!level.field_9236) {
            int smelted = smeltInventory(level, player);
            if (!player.method_31549().field_7477) {
                stack.method_7934(1);
            }
            player.method_7357().method_7906(this, 20);
            level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_15006, class_3419.field_15248, 0.9f, 0.8f);
            if (level instanceof class_3218 sl) {
                sl.method_14199(class_2398.field_11239,
                    player.method_23317(), player.method_23318() + 1.0, player.method_23321(),
                    40, 0.5, 0.5, 0.5, 0.0);
            }
            player.method_6092(new class_1293(ModEffects.SUPER_FIRE_RESISTANCE, 400, 0));
            if (player instanceof class_3222 sp) {
                AdvancementHelper.award(sp, "molten_core_use", "use_molten_core");
            }
        }
        return class_1271.method_22427(stack);
    }

    /** Smelt every furnace-smeltable stack in the player's inventory in place. */
    private int smeltInventory(class_1937 level, class_1657 player) {
        int smelted = 0;
        var recipes = level.method_8433();
        var inventory = player.method_31548();
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 slot = inventory.method_5438(i);
            if (slot.method_7960()) {
                continue;
            }
            class_9696 input = new class_9696(slot);
            var found = recipes.method_8132(class_3956.field_17546, input, level);
            if (found.isPresent()) {
                class_1799 result = found.get().comp_1933().method_59982(input, level.method_30349());
                if (!result.method_7960()) {
                    inventory.method_5447(i, new class_1799(result.method_7909(), slot.method_7947()));
                    smelted += slot.method_7947();
                }
            }
        }
        return smelted;
    }
}
