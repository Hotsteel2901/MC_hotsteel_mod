package com.hotsteel.item;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4770;

/**
 * Hot Steel sword: right-click to strike a burst of fire at whatever block you
 * are looking at (costs durability, short cooldown). Melee hits already ignite
 * targets via the hot-steel melee mixin.
 */
public class HotSteelSwordItem extends class_1829 {

    private static final int COOLDOWN_TICKS = 30;
    private static final int RANGE = 4;
    private static final int DURABILITY_COST = 4;

    public HotSteelSwordItem(class_1832 tier, class_1793 properties) {
        super(tier, properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (player.method_7357().method_7904(this)) {
            return class_1271.method_22431(stack);
        }
        boolean struck = false;
        if (!level.field_9236) {
            struck = strikeFire(level, player);
            if (struck && !player.method_31549().field_7477) {
                stack.method_7970(DURABILITY_COST, player, class_1304.field_6173);
            }
            player.method_7357().method_7906(this, COOLDOWN_TICKS);
        }
        level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
            class_3417.field_15013, class_3419.field_15248, 0.6f, 1.0f);
        return class_1271.method_22427(stack);
    }

    private boolean strikeFire(class_1937 level, class_1657 player) {
        class_243 start = player.method_5836(1.0f);
        class_243 end = start.method_1019(player.method_5720().method_1021(RANGE));
        class_3965 hit = level.method_17742(new class_3959(start, end,
            class_3959.class_3960.field_17559, class_3959.class_242.field_1348, player));
        class_2338 pos;
        if (hit.method_17783() == class_239.class_240.field_1332) {
            pos = hit.method_17777().method_10093(hit.method_17780());
        } else {
            pos = player.method_24515().method_10093(
                class_2350.method_10142(player.method_5720().field_1352, player.method_5720().field_1351, player.method_5720().field_1350));
        }
        class_2680 state = level.method_8320(pos);
        if (state.method_26215() && class_4770.method_30032(level, pos, class_2350.field_11036)) {
            level.method_8652(pos, class_4770.method_24416(level, pos), 3);
            return true;
        }
        return false;
    }
}
