package com.hotsteel.item;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import com.hotsteel.logic.AdvancementHelper;
import com.hotsteel.logic.BlockBreakHelper;

/**
 * Hot Steel axe: besides chopping like a normal axe, breaking a log instantly
 * fells the whole connected trunk above/below it (up to 128 logs) so whole
 * trees drop at once. Tool durability is charged per extra log.
 */
public class HotSteelAxeItem extends class_1743 {

    private static final int MAX_LOGS = 128;

    public HotSteelAxeItem(class_1832 tier, class_1793 properties) {
        super(tier, properties);
    }

    @Override
    public boolean method_7879(class_1799 stack, class_1937 level, class_2680 state, class_2338 pos, class_1309 miner) {
        boolean broken = super.method_7879(stack, level, state, pos, miner);
        if (!level.field_9236 && state.method_26164(class_3481.field_15475) && miner instanceof class_1657 player) {
            fellTree(level, pos, state.method_26204(), player, stack);
        }
        return broken;
    }

    private void fellTree(class_1937 level, class_2338 start, class_2248 logBlock, class_1657 player, class_1799 stack) {
        Set<class_2338> toBreak = new HashSet<>();
        Deque<class_2338> queue = new ArrayDeque<>();
        queue.add(start);
        while (!queue.isEmpty() && toBreak.size() < MAX_LOGS) {
            class_2338 pos = queue.poll();
            if (!toBreak.add(pos)) {
                continue;
            }
            if (!level.method_8320(pos).method_27852(logBlock)) {
                continue;
            }
            for (class_2350 dir : class_2350.values()) {
                class_2338 next = pos.method_10093(dir);
                if (level.method_8320(next).method_27852(logBlock)) {
                    queue.add(next);
                }
            }
        }
        for (class_2338 pos : toBreak) {
            if (pos.equals(start)) {
                continue; // already broken by the normal mining call
            }
            BlockBreakHelper.breakBlock(level, pos, player, stack);
        }
        if (toBreak.size() > 1 && player instanceof net.minecraft.class_3222 serverPlayer) {
            AdvancementHelper.award(serverPlayer, "tree_felling", "fell_tree");
        }
    }
}
