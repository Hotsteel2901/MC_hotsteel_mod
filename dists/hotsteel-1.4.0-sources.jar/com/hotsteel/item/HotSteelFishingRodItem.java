package com.hotsteel.item;

import net.minecraft.class_1787;

/** Hot Steel fishing rod: durable, and any fish it catches are auto-cooked
 *  (see the FishingHook mixin). */
public class HotSteelFishingRodItem extends class_1787 {

    public HotSteelFishingRodItem(class_1793 properties) {
        super(properties);
    }
}
