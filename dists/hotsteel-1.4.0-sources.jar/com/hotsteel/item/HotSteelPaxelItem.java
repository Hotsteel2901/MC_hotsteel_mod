package com.hotsteel.item;

import com.hotsteel.registry.ModMaterials;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1832;
import net.minecraft.class_2680;
import net.minecraft.class_3481;

/**
 * Hot Steel Paxel: a pickaxe + axe + shovel merged into one tool. It mines
 * anything a pickaxe, axe or shovel can, at full Hot Steel speed, and — like
 * the pickaxe — auto-smelts ores (see {@code BlockMixin}).
 */
public class HotSteelPaxelItem extends class_1810 {

    public HotSteelPaxelItem(class_1832 tier, class_1793 properties) {
        super(tier, properties);
    }

    private static boolean isPaxelBlock(class_2680 state) {
        return state.method_26164(class_3481.field_33715)
            || state.method_26164(class_3481.field_33713)
            || state.method_26164(class_3481.field_33716);
    }

    @Override
    public float method_58404(class_1799 stack, class_2680 state) {
        if (isPaxelBlock(state)) {
            return ModMaterials.HotSteelTier.INSTANCE.method_8027();
        }
        return 1.0f;
    }

    @Override
    public boolean method_58405(class_1799 stack, class_2680 state) {
        if (!isPaxelBlock(state)) {
            return false;
        }
        // Hot Steel tier is correct for anything up to netherite level.
        return !state.method_26164(ModMaterials.HotSteelTier.INSTANCE.method_58419());
    }
}
