package com.hotsteel.item;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/**
 * Hot Steel hoe: besides tilling like a normal hoe, right-clicking a fully-grown
 * crop harvests it (plus the surrounding 3x3) and replants it immediately.
 */
public class HotSteelHoeItem extends class_1794 {

    public HotSteelHoeItem(class_1832 tier, class_1792.class_1793 properties) {
        super(tier, properties);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 level = context.method_8045();
        class_2338 pos = context.method_8037();
        class_2680 state = level.method_8320(pos);
        if (state.method_26204() instanceof class_2302 crop && crop.method_9825(state)) {
            if (!level.field_9236) {
                harvestCrops(level, pos);
            }
            class_1657 player = context.method_8036();
            if (player != null && !player.method_31549().field_7477) {
                context.method_8041().method_7970(1, player, class_1304.field_6173);
            }
            return class_1269.field_5812;
        }
        return super.method_7884(context);
    }

    /** Harvest a 3x3 area of mature crops and replant them at age 0. */
    private void harvestCrops(class_1937 level, class_2338 center) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                class_2338 pos = center.method_10069(dx, 0, dz);
                class_2680 state = level.method_8320(pos);
                if (state.method_26204() instanceof class_2302 crop && crop.method_9825(state)) {
                    if (level instanceof class_3218 serverLevel) {
                        List<class_1799> drops = class_2248.method_9562(state, serverLevel, pos, null);
                        for (class_1799 drop : drops) {
                            class_2248.method_9577(level, pos, drop);
                        }
                    }
                    level.method_8652(pos, crop.method_9564(), 3);
                }
            }
        }
    }
}
