package com.hotsteel.item;

import com.hotsteel.entity.HotSteelArrowEntity;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_1744;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2350;
import net.minecraft.class_2374;

/** Hot Steel arrow: flies like a normal arrow but ignites whatever it hits. */
public class HotSteelArrowItem extends class_1744 {

    public HotSteelArrowItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1665 method_7702(class_1937 level, class_1799 stack, class_1309 shooter,
                                     class_1799 leftoverItemStack) {
        return new HotSteelArrowEntity(level, shooter, stack.method_7972(), leftoverItemStack);
    }

    /** Dispenser support: shoot a Hot Steel arrow (no shooter, leftover must be null). */
    @Override
    public class_1676 method_58648(class_1937 level, class_2374 position, class_1799 stack, class_2350 direction) {
        HotSteelArrowEntity arrow = new HotSteelArrowEntity(
            level, position.method_10216(), position.method_10214(), position.method_10215(), stack.method_7972(), null);
        arrow.field_7572 = class_1665.class_1666.field_7593;
        return arrow;
    }
}
