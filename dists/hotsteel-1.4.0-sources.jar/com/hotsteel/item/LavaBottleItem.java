package com.hotsteel.item;

import com.hotsteel.entity.LavaBottleEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;

/** A bottle of liquid lava. Throw it to flood the area with lava and start fires. */
public class LavaBottleItem extends class_1792 {

    public LavaBottleItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!level.field_9236) {
            LavaBottleEntity bottle = new LavaBottleEntity(level, player, stack);
            bottle.method_24919(player, player.method_36455(), player.method_36454(), 0.0f, 1.5f, 1.0f);
            level.method_8649(bottle);
            level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(),
                class_3417.field_14873, class_3419.field_15254, 0.5f, 0.6f);
        }
        if (!player.method_31549().field_7477) {
            stack.method_7934(1);
        }
        player.method_7259(class_3468.field_15372.method_14956(this));
        return class_1271.method_22427(stack);
    }
}
