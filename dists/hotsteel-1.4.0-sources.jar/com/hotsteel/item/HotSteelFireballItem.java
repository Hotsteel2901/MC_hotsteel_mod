package com.hotsteel.item;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1677;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

/** Throwable Hot Steel fireball — a small fireball that explodes and sets things alight. */
public class HotSteelFireballItem extends class_1792 {

    public HotSteelFireballItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (!level.field_9236) {
            class_1677 fireball = new class_1677(level, player, player.method_5720().method_1021(2.0));
            level.method_8649(fireball);
            player.method_7357().method_7906(this, 8);
        }
        if (!player.method_31549().field_7477) {
            stack.method_7934(1);
        }
        return class_1271.method_22427(stack);
    }
}
