package com.hotsteel.item;

import java.util.Set;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1821;
import net.minecraft.class_1832;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import com.hotsteel.logic.AdvancementHelper;
import com.hotsteel.logic.BlockBreakHelper;

/**
 * Hot Steel shovel: sneak + right-click a soft block (dirt, sand, gravel…) to
 * dig a 3x3 area at once. Drops are collected and durability is charged per block.
 */
public class HotSteelShovelItem extends class_1821 {

    private static final Set<class_2248> DIGGABLE = Set.of(
        class_2246.field_10566, class_2246.field_10219, class_2246.field_10253, class_2246.field_28685,
        class_2246.field_10520, class_2246.field_10402, class_2246.field_10102, class_2246.field_10534,
        class_2246.field_10255, class_2246.field_10460, class_2246.field_10114, class_2246.field_22090,
        class_2246.field_37576, class_2246.field_10491, class_2246.field_10477, class_2246.field_37556,
        class_2246.field_10362, class_2246.field_10194);

    public HotSteelShovelItem(class_1832 tier, class_1793 properties) {
        super(tier, properties);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1657 player = context.method_8036();
        class_1937 level = context.method_8045();
        if (player != null && player.method_5715()
            && isDiggable(level.method_8320(context.method_8037()))) {
            if (!level.field_9236) {
                digArea(level, context.method_8037(), player, context.method_8041());
            }
            return class_1269.field_5812;
        }
        return super.method_7884(context);
    }

    private static boolean isDiggable(class_2680 state) {
        return DIGGABLE.contains(state.method_26204());
    }

    private static void digArea(class_1937 level, class_2338 center, class_1657 player, class_1799 tool) {
        int dug = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                class_2338 pos = center.method_10069(dx, 0, dz);
                if (isDiggable(level.method_8320(pos))) {
                    BlockBreakHelper.breakBlock(level, pos, player, tool);
                    dug++;
                }
            }
        }
        if (dug > 1 && player instanceof class_3222 serverPlayer) {
            AdvancementHelper.award(serverPlayer, "area_dig", "dig_3x3");
        }
    }
}
