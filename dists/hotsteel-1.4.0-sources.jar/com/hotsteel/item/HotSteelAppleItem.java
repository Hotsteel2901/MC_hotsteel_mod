package com.hotsteel.item;

import com.hotsteel.registry.ModEffects;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

/**
 * Hot Steel Apple: a molten-hot apple forged from steel. Eating it grants a
 * solid chunk of Fire Resistance plus a burst of Super Fire Resistance (the
 * armor/potion effect) and a short Regeneration.
 */
public class HotSteelAppleItem extends class_1792 {

    public HotSteelAppleItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 level, class_1309 entity) {
        if (!level.field_9236) {
            entity.method_6092(new class_1293(class_1294.field_5918, 600, 0));
            entity.method_6092(new class_1293(ModEffects.SUPER_FIRE_RESISTANCE, 300, 0));
            entity.method_6092(new class_1293(class_1294.field_5924, 120, 1));
        }
        return super.method_7861(stack, level, entity);
    }
}
