package com.hotsteel.item;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1832;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import com.hotsteel.logic.AdvancementHelper;
import com.hotsteel.registry.ModItems;

/**
 * Hot Steel sickle: like a hoe, but right-clicking a mature crop harvests a
 * 5x5 area at once and replants every harvested crop. Vanilla HoeItem's tilling
 * behaviour is inherited for everything else.
 */
public class HotSteelSickleItem extends class_1794 {

    /** Half-width of the harvest box: 5x5 with the clicked block in the middle. */
    private static final int RADIUS = 2;

    public HotSteelSickleItem(class_1832 tier, class_1793 properties) {
        super(tier, properties);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 level = context.method_8045();
        class_2338 pos = context.method_8037();
        class_2680 state = level.method_8320(pos);
        if (state.method_26204() instanceof class_2302 crop && crop.method_9825(state)) {
            if (!level.field_9236) {
                harvestCrops(level, pos);
            }
            class_1657 player = context.method_8036();
            if (player != null && !player.method_31549().field_7477) {
                context.method_8041().method_7970(1, player,
                    net.minecraft.class_1304.field_6173);
            }
            return class_1269.field_5812;
        }
        return super.method_7884(context);
    }

    /** Harvest a 5x5 area of mature crops and replant them at age 0. */
    private void harvestCrops(class_1937 level, class_2338 center) {
        int harvested = 0;
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                class_2338 pos = center.method_10069(dx, 0, dz);
                class_2680 state = level.method_8320(pos);
                if (state.method_26204() instanceof class_2302 crop && crop.method_9825(state)) {
                    if (level instanceof class_3218 serverLevel) {
                        List<class_1799> drops = class_2248.method_9562(state, serverLevel, pos, null);
                        for (class_1799 drop : drops) {
                            class_2248.method_9577(level, pos, drop);
                        }
                    }
                    level.method_8652(pos, crop.method_9564(), 3);
                    harvested++;
                }
            }
        }
        if (harvested > 0
            && level instanceof class_3218 sl
            && sl.method_8604(center.method_10263() + 0.5, center.method_10264() + 0.5, center.method_10260() + 0.5, 8.0,
                    e -> e instanceof class_3222)
                instanceof class_3222 player) {
            AdvancementHelper.award(player, "sickle_harvest", "harvest_5x5");
        }
    }
}
