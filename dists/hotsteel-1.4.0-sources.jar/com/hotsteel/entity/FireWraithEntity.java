package com.hotsteel.entity;

import com.hotsteel.logic.AdvancementHelper;
import com.hotsteel.registry.ModItems;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1545;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * Fire Wraith — a blazing spirit haunting the Nether. It behaves like a Blaze
 * (hovers, shoots fireballs, immune to fire) but burns brighter: it is stronger,
 * drops Molten Cores and Hot Steel ingots, and its fireballs set the ground alight.
 */
public class FireWraithEntity extends class_1545 {

    public FireWraithEntity(class_1299<? extends FireWraithEntity> type, class_1937 level) {
        super(type, level);
    }

    @Override
    public void method_6078(class_1282 source) {
        super.method_6078(source);
        if (!this.method_37908().field_9236) {
            int cores = 1 + this.field_5974.method_43048(2);
            for (int i = 0; i < cores; i++) {
                this.method_5775(new class_1799(ModItems.MOLTEN_CORE));
            }
            if (this.field_5974.method_43048(2) == 0) {
                this.method_5775(new class_1799(ModItems.HOT_STEEL_INGOT));
            }
            if (source.method_5529() instanceof class_3222 killer
                && this.method_37908() instanceof class_3218) {
                AdvancementHelper.award(killer, "fire_wraith", "kill_wraith");
            }
        }
    }
}
