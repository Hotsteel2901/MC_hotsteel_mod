package com.hotsteel.entity;

import com.hotsteel.registry.ModEntities;
import com.hotsteel.registry.ModItems;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1665;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

/**
 * Arrow entity shot from a Hot Steel arrow. Flies exactly like a vanilla arrow
 * (works with bows, crossbows and dispensers) but uses its own entity type so it
 * renders with the molten-hot texture, and ignites whatever it hits.
 * <p>
 * IMPORTANT: the constructor must receive a non-null/non-empty {@code leftover}
 * weapon stack when shot from a bow/crossbow — vanilla throws
 * {@code IllegalArgumentException("Invalid weapon firing an arrow")} when the
 * leftover is an empty stack.
 */
public class HotSteelArrowEntity extends class_1665 {

    /** Fire ticks applied to a hit target (5s). */
    private static final int IGNITE_TICKS = 100;

    public HotSteelArrowEntity(class_1299<? extends HotSteelArrowEntity> type, class_1937 level) {
        super(type, level);
    }

    /** Shot from a bow / crossbow by a living shooter (leftover = the weapon stack). */
    public HotSteelArrowEntity(class_1937 level, class_1309 shooter, class_1799 pickup, class_1799 leftover) {
        super(ModEntities.HOT_STEEL_ARROW, shooter, level, pickup, leftover);
        this.method_7438(2.5);
        this.field_7572 = class_1666.field_7593;
    }

    /** Dispensed from a dispenser/dropper (no shooter). */
    public HotSteelArrowEntity(class_1937 level, double x, double y, double z,
                               class_1799 pickup, class_1799 leftover) {
        super(ModEntities.HOT_STEEL_ARROW, x, y, z, level, pickup, leftover);
        this.method_7438(2.5);
        this.field_7572 = class_1666.field_7593;
    }

    @Override
    protected class_1799 method_57314() {
        return new class_1799(ModItems.HOT_STEEL_ARROW);
    }

    @Override
    protected void method_7450(class_1309 target) {
        super.method_7450(target);
        if (!this.method_37908().method_8608()) {
            target.method_20803(Math.max(target.method_20802(), IGNITE_TICKS));
        }
    }
}
