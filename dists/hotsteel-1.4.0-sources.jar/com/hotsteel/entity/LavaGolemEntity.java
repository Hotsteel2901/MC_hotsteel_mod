package com.hotsteel.entity;

import com.hotsteel.logic.AdvancementHelper;
import com.hotsteel.registry.ModItems;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1439;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import org.jetbrains.annotations.Nullable;

/**
 * Lava Golem — a molten guardian forged from Hot Steel. It is immune to fire and
 * lava, floats on the surface of lava, burns whatever damages it, and drops Hot
 * Steel ingots when it dies. Crafted by a player, it stays peaceful unless provoked.
 */
public class LavaGolemEntity extends class_1439 {

    public LavaGolemEntity(class_1299<? extends LavaGolemEntity> type, class_1937 level) {
        super(type, level);
        this.method_6499(true);
        this.method_5971();
    }

    public static class_5132.class_5133 method_26886() {
        return class_1308.method_26828()
            .method_26868(class_5134.field_23716, 80.0)
            .method_26868(class_5134.field_23719, 0.26)
            .method_26868(class_5134.field_23718, 1.0)
            .method_26868(class_5134.field_23721, 10.0)
            .method_26868(class_5134.field_23724, 6.0);
    }

    @Override
    @Nullable
    public class_1315 method_5943(class_5425 level, class_1266 difficulty,
                                        class_3730 spawnType, @Nullable class_1315 spawnData) {
        class_1315 data = super.method_5943(level, difficulty, spawnType, spawnData);
        if (spawnType == class_3730.field_16465 && level instanceof class_3218 serverLevel) {
            net.minecraft.class_1657 nearest = serverLevel.method_18460(this, 12.0);
            if (nearest instanceof class_3222 serverPlayer) {
                AdvancementHelper.award(serverPlayer, "lava_golem", "summon_golem");
            }
        }
        return data;
    }

    @Override
    public boolean method_5753() {
        return true;
    }

    @Override
    public boolean method_5643(class_1282 source, float amount) {
        boolean hurt = super.method_5643(source, amount);
        if (hurt && !this.method_37908().field_9236) {
            if (source.method_5526() instanceof class_1309 attacker && attacker != this) {
                attacker.method_20803(Math.max(attacker.method_20802(), 100));
            }
        }
        return hurt;
    }

    @Override
    public void method_6007() {
        super.method_6007();
        if (this.method_37908().field_9236) {
            return;
        }
        // Float on the surface of lava like a buoyant forge-heart, and slowly
        // mend itself while submerged in the molten rock.
        if (this.method_5771()) {
            if (this.field_6012 % 20 == 0 && this.method_6032() < this.method_6063()) {
                this.method_6025(1.0f);
            }
            this.method_18800(this.method_18798().field_1352, 0.16, this.method_18798().field_1350);
            if (this.field_5974.method_43048(4) == 0) {
                this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(),
                    class_3417.field_14576, class_3419.field_15245, 0.4f, 1.2f);
            }
            if (this.method_37908() instanceof class_3218 serverLevel) {
                class_2338 pos = this.method_24515();
                serverLevel.method_14199(class_2398.field_11239,
                    this.method_23317(), this.method_23318() + 0.5, this.method_23321(), 3, 0.4, 0.2, 0.4, 0.0);
                serverLevel.method_14199(class_2398.field_11251,
                    this.method_23317(), this.method_23318() + this.method_17682(), this.method_23321(), 2, 0.3, 0.1, 0.3, 0.0);
            }
        }
    }

    @Override
    public void method_6078(class_1282 source) {
        super.method_6078(source);
        if (!this.method_37908().field_9236) {
            int count = 2 + this.field_5974.method_43048(3);
            for (int i = 0; i < count; i++) {
                this.method_5775(new class_1799(ModItems.HOT_STEEL_INGOT));
            }
        }
    }
}
