package com.hotsteel.entity;

import com.hotsteel.registry.ModEntities;
import com.hotsteel.registry.ModItems;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3612;
import net.minecraft.class_3857;
import net.minecraft.class_3965;

/**
 * A thrown bottle of liquid lava. Shatters on impact, flooding the surrounding
 * blocks with lava and igniting the area.
 */
public class LavaBottleEntity extends class_3857 {

    public LavaBottleEntity(class_1299<? extends LavaBottleEntity> type, class_1937 level) {
        super(type, level);
    }

    public LavaBottleEntity(class_1937 level, class_1309 shooter, class_1799 stack) {
        super(ModEntities.LAVA_BOTTLE, shooter, level);
        this.method_16940(stack);
    }

    public LavaBottleEntity(class_1937 level, double x, double y, double z, class_1799 stack) {
        super(ModEntities.LAVA_BOTTLE, x, y, z, level);
        this.method_16940(stack);
    }

    @Override
    protected class_1792 method_16942() {
        return ModItems.LAVA_BOTTLE;
    }

    @Override
    protected void method_7488(class_239 result) {
        super.method_7488(result);
        if (this.method_37908().field_9236) {
            return;
        }
        class_3218 serverLevel = (class_3218) this.method_37908();
        serverLevel.method_14199(class_2398.field_11239,
            this.method_23317(), this.method_23318(), this.method_23321(), 40, 0.5, 0.5, 0.5, 0.1);
        this.method_37908().method_43128(null, this.method_23317(), this.method_23318(), this.method_23321(),
            class_3417.field_15222, class_3419.field_15245, 1.0f, 0.8f);

        class_2338 center = this.method_24515();
        if (result instanceof class_3965 blockHit) {
            center = blockHit.method_17777();
        }
        splashLava(serverLevel, center);
        this.method_31472();
    }

    /** Flood a 3x3 horizontal area (and one block down) with lava where possible, then ignite the rim. */
    private static void splashLava(class_3218 level, class_2338 center) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                class_2338 pos = center.method_10069(dx, 0, dz);
                tryPlaceLava(level, pos);
                tryPlaceLava(level, pos.method_10074());
            }
        }
        // Ignite a wider ring around the impact
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) < 2) {
                    continue;
                }
                class_2338 pos = center.method_10069(dx, 0, dz);
                class_2680 state = level.method_8320(pos);
                class_2680 below = level.method_8320(pos.method_10074());
                if (state.method_26215() && !below.method_26215() && below.method_26227().method_15769()) {
                    level.method_8652(pos, class_2246.field_10036.method_9564(), 3);
                }
            }
        }
    }

    private static void tryPlaceLava(class_3218 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        if (state.method_26188(class_3612.field_15908)) {
            level.method_8652(pos, class_2246.field_10164.method_9564(), 3);
        }
    }
}
