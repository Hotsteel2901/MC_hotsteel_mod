package com.hotsteel.mixin;

import java.util.Map;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import com.hotsteel.registry.ModItems;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hot Steel fishing rod: any raw fish caught with it is cooked instantly.
 * The {@code retrieve} method drops the catch into the player's inventory, so we
 * scan the inventory right after and upgrade raw fish to their cooked form.
 */
@Mixin(class_1536.class)
public abstract class FishingHookMixin {

    @Unique
    private static final Map<class_1792, class_1792> COOKED = Map.of(
        class_1802.field_8429, class_1802.field_8373,
        class_1802.field_8209, class_1802.field_8509);

    @Inject(method = "retrieve", at = @At("TAIL"))
    private void hotsteel$cookFish(class_1799 stack, CallbackInfoReturnable<Integer> cir) {
        class_1536 self = (class_1536) (Object) this;
        if (self.method_37908().field_9236) {
            return;
        }
        class_1657 player = self.method_6947();
        if (player == null
            || !(player.method_6047().method_31574(ModItems.HOT_STEEL_FISHING_ROD)
                || player.method_6079().method_31574(ModItems.HOT_STEEL_FISHING_ROD))) {
            return;
        }
        class_1661 inv = player.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 slot = inv.method_5438(i);
            class_1792 cooked = COOKED.get(slot.method_7909());
            if (cooked != null && !slot.method_7960()) {
                inv.method_5447(i, new class_1799(cooked, slot.method_7947()));
            }
        }
    }
}
