package com.hotsteel.mixin;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import com.hotsteel.logic.AdvancementHelper;
import com.hotsteel.logic.AutoSmeltHelper;
import com.hotsteel.registry.ModItems;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Auto-smelt: a Hot Steel pickaxe "melts" mined ore on the spot, converting the
 * drops into their smelted (ingot) form. Applied when the block's drops are
 * computed, so it works with Fortune/Silk Touch the same way vanilla would.
 * <p>
 * Only a curated set of ores/raw materials is smelted — ordinary stone etc. is
 * left untouched so the pickaxe doesn't remove cobblestone etc. from gameplay.
 * <p>
 * NOTE: the smelt map lives in {@link AutoSmeltHelper}, not as a mixin
 * {@code @Unique} static field — a static initializer there would force
 * {@code Items}/{@code Blocks} to load inside {@code Block}'s own static
 * initializer and crash vanilla {@code FireBlock} with a circular-init NPE.
 */
@Mixin(class_2248.class)
public abstract class BlockMixin {

    @Inject(method = "getDrops(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/item/ItemStack;)Ljava/util/List;",
            at = @At("RETURN"), cancellable = true)
    private static void hotsteel$autoSmelt(class_2680 state, class_3218 level, class_2338 pos,
                                           class_2586 blockEntity, class_1297 entity, class_1799 tool,
                                           CallbackInfoReturnable<List<class_1799>> cir) {
        if (!tool.method_31574(ModItems.HOT_STEEL_PICKAXE) && !tool.method_31574(ModItems.HOT_STEEL_PAXEL)) {
            return;
        }
        List<class_1799> original = cir.getReturnValue();
        boolean changed = false;
        List<class_1799> result = new ArrayList<>(original.size());
        for (class_1799 stack : original) {
            class_1792 smelted = AutoSmeltHelper.SMELT_MAP.get(stack.method_7909());
            if (smelted != null) {
                result.add(new class_1799(smelted, stack.method_7947()));
                changed = true;
            } else {
                result.add(stack.method_7972());
            }
        }
        if (changed) {
            cir.setReturnValue(result);
            if (entity instanceof class_3222 player) {
                AdvancementHelper.award(player, "auto_smelt", "smelt_ore");
            }
        }
    }
}
