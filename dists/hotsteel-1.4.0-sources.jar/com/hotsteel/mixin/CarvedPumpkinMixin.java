package com.hotsteel.mixin;

import com.hotsteel.entity.LavaGolemEntity;
import com.hotsteel.logic.AdvancementHelper;
import com.hotsteel.registry.ModBlocks;
import com.hotsteel.registry.ModEntities;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2276;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Lets players summon a Lava Golem exactly like an Iron Golem — build a
 * T-shape out of Hot Steel blocks and place a carved pumpkin on top. The whole
 * structure is consumed and a player-created Lava Golem appears. This makes the
 * golem fully obtainable in survival mode (no spawn egg needed).
 */
@Mixin(class_2276.class)
public abstract class CarvedPumpkinMixin {

    /**
     * Runs every time a carved pumpkin / jack o'lantern is placed. Mirrors the
     * vanilla iron-golem structure check but for Hot Steel blocks:
     * <pre>
     *   ~ ^ ~    top    (the pumpkin head being placed)
     *   # # #    middle (torso + arms)
     *   ~ # ~    bottom (legs)
     * </pre>
     */
    @Inject(method = "trySpawnGolem", at = @At("HEAD"), cancellable = true)
    private void hotsteel$trySpawnLavaGolem(class_1937 level, class_2338 pos, CallbackInfo ci) {
        if (level.field_9236) {
            return;
        }
        if (!isHotSteel(level, pos.method_10074())
            || !isHotSteel(level, pos.method_10074().method_10078())
            || !isHotSteel(level, pos.method_10074().method_10067())
            || !isHotSteel(level, pos.method_10087(2))) {
            return;
        }
        // Like vanilla, the air cells around the body must not be full of fluid.
        if (!isEmptyFluid(level, pos.method_10074().method_10095())
            || !isEmptyFluid(level, pos.method_10074().method_10072())
            || !isEmptyFluid(level, pos.method_10087(2).method_10078())
            || !isEmptyFluid(level, pos.method_10087(2).method_10067())) {
            return;
        }

        LavaGolemEntity golem = ModEntities.LAVA_GOLEM.method_5883(level);
        if (golem == null) {
            return;
        }
        consumeStructure(level, pos);
        golem.method_6499(true);
        float yaw = class_3532.method_15393(level.field_9229.method_43057() * 360.0F);
        golem.method_5808(pos.method_10263() + 0.5, pos.method_10087(2).method_10264() + 0.05, pos.method_10260() + 0.5, yaw, 0.0F);
        level.method_8649(golem);
        if (level instanceof class_3218 serverLevel) {
            net.minecraft.class_1657 nearest = serverLevel.method_18460(golem, 12.0);
            if (nearest instanceof class_3222 serverPlayer) {
                AdvancementHelper.award(serverPlayer, "lava_golem", "summon_golem");
            }
        }
        ci.cancel();
    }

    @Unique
    private static boolean isHotSteel(class_1937 level, class_2338 pos) {
        return level.method_8320(pos).method_27852(ModBlocks.HOT_STEEL_BLOCK);
    }

    @Unique
    private static boolean isEmptyFluid(class_1937 level, class_2338 pos) {
        return level.method_8316(pos).method_15769();
    }

    /** Remove the head + 4 body blocks with vanilla-style break effects. */
    @Unique
    private static void consumeStructure(class_1937 level, class_2338 head) {
        class_2338[] positions = {
            head, head.method_10074(), head.method_10074().method_10078(), head.method_10074().method_10067(), head.method_10087(2)
        };
        for (class_2338 p : positions) {
            class_2680 state = level.method_8320(p);
            level.method_8652(p, class_2246.field_10124.method_9564(), 2);
            level.method_8474(2001, p, class_2248.method_9507(state));
        }
    }
}
