package com.hotsteel.mixin;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1738;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import com.hotsteel.registry.ModBlocks;
import com.hotsteel.registry.ModItems;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Adds lore lines to Hot Steel items describing their passive traits:
 * melee weapons ignite targets, the pickaxe auto-smelts ores, and armor pieces
 * describe the 2-piece / 4-piece set bonuses.
 */
@Mixin(class_1792.class)
public abstract class ItemTooltipMixin {

    @Inject(method = "appendHoverText", at = @At("TAIL"))
    private void hotsteel$addLore(class_1799 stack, class_1792.class_9635 context,
                                  List<class_2561> tooltip, class_1836 flag, CallbackInfo ci) {
        class_1792 item = stack.method_7909();
        if (item == ModItems.HOT_STEEL_PICKAXE) {
            tooltip.add(class_2561.method_43471("item.hotsteel.hot_steel_pickaxe.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.HOT_STEEL_SWORD) {
            tooltip.add(class_2561.method_43471("item.hotsteel.hot_steel_sword.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.HOT_STEEL_AXE) {
            tooltip.add(class_2561.method_43471("item.hotsteel.hot_steel_axe.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.HOT_STEEL_SHOVEL) {
            tooltip.add(class_2561.method_43471("item.hotsteel.hot_steel_shovel.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.HOT_STEEL_HOE) {
            tooltip.add(class_2561.method_43471("item.hotsteel.hot_steel_hoe.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.HOT_STEEL_KNIFE || item == ModItems.HOT_STEEL_MACE
            || item == ModItems.HOT_STEEL_TRIDENT) {
            tooltip.add(class_2561.method_43471("item.hotsteel.melee.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.HOT_STEEL_ARROW) {
            tooltip.add(class_2561.method_43471("item.hotsteel.hot_steel_arrow.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.HOT_STEEL_FIREBALL) {
            tooltip.add(class_2561.method_43471("item.hotsteel.hot_steel_fireball.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.LAVA_BOTTLE) {
            tooltip.add(class_2561.method_43471("item.hotsteel.lava_bottle.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.LAVA_GOLEM_SPAWN_EGG) {
            tooltip.add(class_2561.method_43471("item.hotsteel.lava_golem_spawn_egg.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.FIRE_WRAITH_SPAWN_EGG) {
            tooltip.add(class_2561.method_43471("item.hotsteel.fire_wraith_spawn_egg.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.HOT_STEEL_FISHING_ROD) {
            tooltip.add(class_2561.method_43471("item.hotsteel.hot_steel_fishing_rod.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.HOT_STEEL_SICKLE) {
            tooltip.add(class_2561.method_43471("item.hotsteel.hot_steel_sickle.lore")
                .method_27692(class_124.field_1065));
        } else if (item == ModItems.MOLTEN_CORE) {
            tooltip.add(class_2561.method_43471("item.hotsteel.molten_core.lore")
                .method_27692(class_124.field_1065));
        } else if (item instanceof class_1747 blockItem) {
            class_2248 block = blockItem.method_7711();
            if (block == ModBlocks.HOT_STEEL_FORGE) {
                tooltip.add(class_2561.method_43471("block.hotsteel.hot_steel_forge.lore")
                    .method_27692(class_124.field_1065));
            } else if (block == ModBlocks.HOT_STEEL_SMELTER) {
                tooltip.add(class_2561.method_43471("block.hotsteel.hot_steel_smelter.lore")
                    .method_27692(class_124.field_1065));
            } else if (block == ModBlocks.HOT_STEEL_PRESSURE_PLATE) {
                tooltip.add(class_2561.method_43471("block.hotsteel.hot_steel_pressure_plate.lore")
                    .method_27692(class_124.field_1065));
            }
        } else if (item instanceof class_1738 armor) {
            if (armor.method_7685() == class_1304.field_6169
                || armor.method_7685() == class_1304.field_6174
                || armor.method_7685() == class_1304.field_6172
                || armor.method_7685() == class_1304.field_6166) {
                tooltip.add(class_2561.method_43471("item.hotsteel.armor.lore")
                    .method_27692(class_124.field_1065));
            }
        }
    }
}
